# Liga 82 – Historial de cambios

## Versión 1.8
- Nuevo Reporte de jornada en PDF, diseño vertical tamaño carta para impresión y publicación.
- Encabezado con identidad del torneo, jornada destacada y tarjetas de partidos con fecha, hora, equipos, cancha y árbitro.
- Campo de observaciones al pie; no muestra estados ni resultados.
- Nuevo Calendario general en PDF, compacto, con todas las jornadas y datos de programación; omite estados y resultados.
- Se conservan los reportes de resultados y tabla de posiciones, así como las funciones anteriores.

## Versión 1.7
- Exportación de equipos, fixture y tabla de posiciones a Excel.
