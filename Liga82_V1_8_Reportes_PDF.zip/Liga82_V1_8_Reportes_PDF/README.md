# Liga 82 – Versión 1.8

Aplicación de escritorio para administración de torneos de fútbol.

## Instalación

1. Descomprime el ZIP en una carpeta nueva.
2. Conserva/copia tu `liga82.db` y la carpeta `logos` desde tu instalación anterior, si corresponde.
3. Instala dependencias:

   `python -m pip install -r requirements.txt`

4. Ejecuta:

   `python main.py`

## Novedades V1.8

- **Reporte de jornada:** PDF vertical tamaño carta, pensado para imprimir y colocar en espacios públicos. Incluye torneo, temporada, jornada, fecha y hora de cada partido, equipos, cancha, árbitro y observaciones. No incluye estado ni marcador.
- **Calendario general:** PDF compacto con todas las jornadas, fechas, horarios, equipos, cancha y árbitro. No incluye estado ni marcador.
- Se mantienen exportación a Excel, reportes de resultados, tabla de posiciones y respaldos.

La base de datos no se modifica al generar reportes.
