import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "liga82.db"

class Database:
    def __init__(self, path=DB_PATH):
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self._init()

    def _columns(self, table):
        return {row["name"] for row in self.conn.execute(f"PRAGMA table_info({table})")}

    def _init(self):
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS tournament (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            name TEXT NOT NULL,
            season TEXT NOT NULL,
            rounds TEXT NOT NULL DEFAULT 'Una vuelta',
            points_win INTEGER NOT NULL DEFAULT 3,
            points_draw INTEGER NOT NULL DEFAULT 1,
            points_loss INTEGER NOT NULL DEFAULT 0,
            logo_path TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL COLLATE NOCASE UNIQUE,
            city TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS matches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            round_no INTEGER NOT NULL,
            home TEXT NOT NULL,
            away TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS fields (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL COLLATE NOCASE UNIQUE,
            address TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS referees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL COLLATE NOCASE UNIQUE,
            phone TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS app_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        """)
        tournament_cols = self._columns("tournament")
        if "logo_path" not in tournament_cols:
            self.conn.execute("ALTER TABLE tournament ADD COLUMN logo_path TEXT NOT NULL DEFAULT ''")
        team_cols = self._columns("teams")
        for name, definition in {
            "manager": "TEXT NOT NULL DEFAULT ''",
            "logo_path": "TEXT NOT NULL DEFAULT ''",
            "home_field": "TEXT NOT NULL DEFAULT ''",
            "notes": "TEXT NOT NULL DEFAULT ''",
        }.items():
            if name not in team_cols:
                self.conn.execute(f"ALTER TABLE teams ADD COLUMN {name} {definition}")
        cols = self._columns("matches")
        if "home_goals" not in cols:
            self.conn.execute("ALTER TABLE matches ADD COLUMN home_goals INTEGER")
        if "away_goals" not in cols:
            self.conn.execute("ALTER TABLE matches ADD COLUMN away_goals INTEGER")
        if "status" not in cols:
            self.conn.execute("ALTER TABLE matches ADD COLUMN status TEXT NOT NULL DEFAULT 'Pendiente'")
        for name, definition in {
            "match_date": "TEXT NOT NULL DEFAULT ''",
            "match_time": "TEXT NOT NULL DEFAULT ''",
            "field_id": "INTEGER",
            "referee_id": "INTEGER",
            "duration_min": "INTEGER NOT NULL DEFAULT 90",
            "schedule_notes": "TEXT NOT NULL DEFAULT ''",
        }.items():
            if name not in cols:
                self.conn.execute(f"ALTER TABLE matches ADD COLUMN {name} {definition}")
        # Normaliza los estados heredados sin alterar estados especiales ni resultados ya capturados.
        self.conn.execute("UPDATE matches SET status='Pendiente' WHERE (match_date='' OR match_time='') AND status='Programado' AND home_goals IS NULL AND away_goals IS NULL")
        self.conn.execute("UPDATE matches SET status='Programado' WHERE match_date<>'' AND match_time<>'' AND status='Pendiente' AND home_goals IS NULL AND away_goals IS NULL")
        self.conn.commit()


    def get_setting(self, key, default=None):
        row = self.conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key, value):
        self.conn.execute("INSERT INTO app_settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
        self.conn.commit()

    def save_config(self, name, season, rounds, pw, pd, pl, logo_path=''):
        self.conn.execute("""INSERT INTO tournament
            (id,name,season,rounds,points_win,points_draw,points_loss,logo_path)
            VALUES (1,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET name=excluded.name, season=excluded.season,
            rounds=excluded.rounds, points_win=excluded.points_win,
            points_draw=excluded.points_draw, points_loss=excluded.points_loss,
            logo_path=excluded.logo_path""",
            (name, season, rounds, pw, pd, pl, logo_path))
        self.conn.commit()

    def get_config(self):
        row = self.conn.execute("SELECT * FROM tournament WHERE id=1").fetchone()
        return dict(row) if row else None

    def add_team(self, name, city):
        self.conn.execute("INSERT INTO teams(name,city) VALUES (?,?)", (name, city))
        self.conn.commit()

    def update_team_profile(self, team_id, manager, logo_path, home_field, notes):
        self.conn.execute("UPDATE teams SET manager=?, logo_path=?, home_field=?, notes=? WHERE id=?",
                          (manager, logo_path, home_field, notes, team_id))
        self.conn.commit()

    def get_teams(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM teams ORDER BY name")]

    def delete_team(self, team_id):
        self.conn.execute("DELETE FROM teams WHERE id=?", (team_id,))
        self.conn.execute("DELETE FROM matches")
        self.conn.commit()

    def replace_matches(self, pairings):
        self.conn.execute("DELETE FROM matches")
        self.conn.executemany("INSERT INTO matches(round_no,home,away,status) VALUES (?,?,?,'Pendiente')", pairings)
        self.conn.commit()

    def get_matches(self):
        return [dict(r) for r in self.conn.execute("""SELECT m.*, f.name AS field_name, r.name AS referee_name
            FROM matches m LEFT JOIN fields f ON f.id=m.field_id
            LEFT JOIN referees r ON r.id=m.referee_id ORDER BY m.round_no,m.id""")]

    def get_fields(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM fields ORDER BY name")]

    def add_field(self, name, address=''):
        self.conn.execute("INSERT INTO fields(name,address) VALUES (?,?)", (name, address))
        self.conn.commit()

    def delete_field(self, field_id):
        self.conn.execute("UPDATE matches SET field_id=NULL WHERE field_id=?", (field_id,))
        self.conn.execute("DELETE FROM fields WHERE id=?", (field_id,))
        self.conn.commit()

    def get_referees(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM referees ORDER BY name")]

    def add_referee(self, name, phone=''):
        self.conn.execute("INSERT INTO referees(name,phone) VALUES (?,?)", (name, phone))
        self.conn.commit()

    def delete_referee(self, referee_id):
        self.conn.execute("UPDATE matches SET referee_id=NULL WHERE referee_id=?", (referee_id,))
        self.conn.execute("DELETE FROM referees WHERE id=?", (referee_id,))
        self.conn.commit()

    def schedule_match(self, match_id, match_date, match_time, field_id, referee_id, duration_min, notes):
        self.conn.execute("""UPDATE matches SET match_date=?,match_time=?,field_id=?,referee_id=?,
            duration_min=?,schedule_notes=?, status=CASE WHEN status IN ('Suspendido','Reprogramado','Jugado') THEN status ELSE 'Programado' END WHERE id=?""",
            (match_date, match_time, field_id, referee_id, duration_min, notes, match_id))
        self.conn.commit()

    def get_schedule_conflicts(self, match_id, match_date, match_time, duration_min, field_id, referee_id):
        from datetime import datetime, timedelta
        start = datetime.strptime(f"{match_date} {match_time}", "%Y-%m-%d %H:%M")
        end = start + timedelta(minutes=duration_min)
        conflicts = []
        for row in self.conn.execute("""SELECT m.id,m.round_no,m.home,m.away,m.match_time,m.duration_min,
            m.field_id,m.referee_id,f.name AS field_name,r.name AS referee_name
            FROM matches m LEFT JOIN fields f ON f.id=m.field_id
            LEFT JOIN referees r ON r.id=m.referee_id
            WHERE m.id<>? AND m.match_date=? AND m.match_time<>''""", (match_id, match_date)):
            other_start = datetime.strptime(f"{match_date} {row['match_time']}", "%Y-%m-%d %H:%M")
            other_end = other_start + timedelta(minutes=row['duration_min'] or 90)
            if start < other_end and other_start < end:
                if field_id is not None and row['field_id'] == field_id:
                    conflicts.append(f"Cancha {row['field_name'] or ''}: Jornada {row['round_no']} {row['home']} vs {row['away']} ({row['match_time']}).")
                if referee_id is not None and row['referee_id'] == referee_id:
                    conflicts.append(f"Árbitro {row['referee_name'] or ''}: Jornada {row['round_no']} {row['home']} vs {row['away']} ({row['match_time']}).")
        return conflicts

    def get_match(self, match_id):
        row = self.conn.execute("SELECT * FROM matches WHERE id=?", (match_id,)).fetchone()
        return dict(row) if row else None

    def update_match_result(self, match_id, home_goals, away_goals, status=None):
        # Un marcador completo convierte automáticamente el partido en Jugado.
        if home_goals is not None and away_goals is not None:
            final_status = 'Jugado'
        else:
            final_status = status or 'Pendiente'
        self.conn.execute("""UPDATE matches SET home_goals=?, away_goals=?, status=? WHERE id=?""",
                          (home_goals, away_goals, final_status, match_id))
        self.conn.commit()

    def get_standings(self):
        cfg = self.get_config() or {"points_win": 3, "points_draw": 1, "points_loss": 0}
        pw, pd, pl = cfg["points_win"], cfg["points_draw"], cfg["points_loss"]
        table = {}
        for team in self.get_teams():
            table[team["name"]] = {
                "team": team["name"], "pj": 0, "pg": 0, "pe": 0, "pp": 0,
                "gf": 0, "gc": 0, "dif": 0, "pts": 0
            }
        matches = self.conn.execute(
            "SELECT home,away,home_goals,away_goals FROM matches WHERE status='Jugado' AND home_goals IS NOT NULL AND away_goals IS NOT NULL"
        )
        for m in matches:
            home, away = m["home"], m["away"]
            if home not in table or away not in table:
                continue
            hg, ag = m["home_goals"], m["away_goals"]
            h, a = table[home], table[away]
            h["pj"] += 1; a["pj"] += 1
            h["gf"] += hg; h["gc"] += ag
            a["gf"] += ag; a["gc"] += hg
            if hg > ag:
                h["pg"] += 1; a["pp"] += 1
                h["pts"] += pw; a["pts"] += pl
            elif hg < ag:
                a["pg"] += 1; h["pp"] += 1
                a["pts"] += pw; h["pts"] += pl
            else:
                h["pe"] += 1; a["pe"] += 1
                h["pts"] += pd; a["pts"] += pd
        for row in table.values():
            row["dif"] = row["gf"] - row["gc"]
        return sorted(table.values(), key=lambda r: (-r["pts"], -r["dif"], -r["gf"], r["team"].casefold()))

    def close(self):
        self.conn.close()
