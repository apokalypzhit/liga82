# Liga 82 – Historial de cambios

## Versión 1.9
- Cinco plantillas de diseño seleccionables para los tres reportes PDF.
- Selector de plantilla en Reportes PDF.
- Se recuerda la última plantilla elegida mediante la configuración local.
- Se conserva la estructura de datos y las funciones anteriores.

# Liga 82 – Historial de cambios

## Versión 1.8
- Nuevo Reporte de jornada en PDF, diseño vertical tamaño carta para impresión y publicación.
- Encabezado con identidad del torneo, jornada destacada y tarjetas de partidos con fecha, hora, equipos, cancha y árbitro.
- Campo de observaciones al pie; no muestra estados ni resultados.
- Nuevo Calendario general en PDF, compacto, con todas las jornadas y datos de programación; omite estados y resultados.
- Se conservan los reportes de resultados y tabla de posiciones, así como las funciones anteriores.

## Versión 1.7
- Exportación de equipos, fixture y tabla de posiciones a Excel.

- Los tres reportes PDF incorporan el logotipo del torneo cuando está configurado.
- Se muestran los escudos guardados en las fichas de equipo en programación, calendario y tabla de posiciones; si falta un escudo, se conserva el nombre del equipo sin imagen.

### Ajuste visual de escudos en enfrentamientos
- En los reportes de partidos, el escudo del equipo local se coloca después del nombre.
- El escudo del visitante se coloca antes del nombre, orientando visualmente ambos equipos hacia el centro del enfrentamiento.
- Aplicado a la programación de jornada y al calendario general.


### Acabado gráfico adicional
- Se incorporan fondos deportivos propios para cada una de las cinco plantillas, con iluminación de estadio, franjas dinámicas y silueta de cancha.
- Los fondos se aplican en todas las páginas y mantienen una capa clara para priorizar la lectura e impresión de los datos.

### Ajustes visuales posteriores
- Se aumentó la visibilidad de los fondos deportivos sin reducir la legibilidad del contenido.
- Las filas alternadas de calendarios y tablas ahora respetan la paleta de cada plantilla.
- La tabla de posiciones destaca la columna de puntos y resalta visualmente al primer lugar.
- Se amplió ligeramente el tamaño de lectura y el espacio de las filas de posiciones.


### Refinamiento gráfico a partir de capturas reales
- Se hizo más visible el fondo deportivo reduciendo la opacidad del panel de lectura, manteniendo contraste en las tablas y tarjetas.
- Se aumentó ligeramente el tamaño de los escudos en calendario y tabla de posiciones.
- Se amplió el tratamiento visual del podio para distinguir los tres primeros lugares sin modificar estadísticas ni clasificación.

### Ajustes solicitados de presentación
- Calendario General sin fondos decorativos ni estilos gráficos de plantilla; conserva un formato sobrio para consulta interna.
- Tabla General de Posiciones: se elimina el resaltado tipo podio y se muestran en negritas las primeras ocho posiciones.
- Se mantienen los diseños deportivos para Reporte de Jornada y Tabla de Posiciones.
