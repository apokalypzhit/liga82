# Liga 82 – Versión 1.9

Aplicación de escritorio para administración de torneos de fútbol.

## Instalación
1. Descomprime el ZIP en una carpeta nueva.
2. Conserva/copia tu `liga82.db` y la carpeta `logos` desde tu instalación anterior, si corresponde.
3. Instala dependencias: `python -m pip install -r requirements.txt`
4. Ejecuta: `python main.py`

## Novedades V1.9
- Cinco plantillas visuales seleccionables para los tres reportes PDF: Deportivo moderno, Liga profesional, Fútbol clásico, Impacto deportivo y Minimalista premium.
- La aplicación recuerda la última plantilla seleccionada.
- Los estilos coordinan encabezados, tarjetas de jornada y tablas.
- Los reportes utilizan el logotipo configurado en la ficha del torneo.
- Los escudos de equipo se toman de las fichas existentes y aparecen junto a sus nombres en los tres reportes; son opcionales.
- Se conservan las funciones de V1.8 y anteriores. La selección de plantilla se guarda en la configuración local de la aplicación.

La base de datos del torneo no cambia su estructura al generar reportes.

- Acabado gráfico adicional: fondos deportivos diferenciados por plantilla con luces de estadio, franjas dinámicas y cancha estilizada.

### Ajustes gráficos de esta compilación
- Mayor presencia de los fondos de cada plantilla.
- Colores de filas coordinados con el diseño seleccionado.
- Columna de puntos y primer lugar destacados en la tabla general.
