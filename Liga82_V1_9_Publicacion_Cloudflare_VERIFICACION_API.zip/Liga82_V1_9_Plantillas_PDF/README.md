# Liga 82 – Versión 1.9

Aplicación de escritorio para administración de torneos de fútbol.

## Instalación
1. Descomprime el ZIP en una carpeta nueva.
2. Conserva/copia tu `liga82.db` y la carpeta `logos` desde tu instalación anterior, si corresponde.
3. Instala dependencias: `python -m pip install -r requirements.txt`
4. Ejecuta: `python main.py`

## Novedades V1.9
- Cinco plantillas visuales seleccionables para los tres reportes PDF: Deportivo moderno, Liga profesional, Fútbol clásico, Impacto deportivo y Minimalista premium.
- La aplicación recuerda la última plantilla seleccionada.
- Los estilos coordinan encabezados, tarjetas de jornada y tablas.
- Los reportes utilizan el logotipo configurado en la ficha del torneo.
- Los escudos de equipo se toman de las fichas existentes y aparecen junto a sus nombres en los tres reportes; son opcionales.
- Se conservan las funciones de V1.8 y anteriores. La selección de plantilla se guarda en la configuración local de la aplicación.

La base de datos del torneo no cambia su estructura al generar reportes.

- Acabado gráfico adicional: fondos deportivos diferenciados por plantilla con luces de estadio, franjas dinámicas y cancha estilizada.

### Ajustes gráficos de esta compilación
- Mayor presencia de los fondos de cada plantilla.
- Colores de filas coordinados con el diseño seleccionado.
- Columna de puntos y primer lugar destacados en la tabla general.

## Generador de carteles (módulo inicial)
- Nueva pestaña independiente: **Generador de carteles**.
- Selección de jornada y vista previa vertical 1080 × 1350 px.
- Fondo de estadio generado localmente o fondo personalizado seleccionado por el usuario.
- Usa el logotipo del torneo y los escudos de las fichas de equipo existentes.
- Tarjetas automáticas para jornadas de 1 a 10 partidos; no incluye número de partido, resultados ni estado.
- Datos mostrados: fecha, hora y cancha. Los datos faltantes se indican como "por confirmar".
- Administración de patrocinadores: agregar varios logotipos, eliminarlos, cambiar orden y activar/desactivar su aparición.
- Exportación a JPG o PNG.
- Los fondos, logotipos de patrocinadores y preferencias se guardan en `logos/poster_assets` y `app_settings`; no se agregan tablas ni se cambia el esquema de la base de datos.
- Dependencia adicional: Pillow, instalada con `python -m pip install -r requirements.txt`.


## Publicación web de la Tabla General
- Nueva pestaña **Publicación web** para generar una página HTML independiente con la tabla de posiciones actual.
- Diseño adaptable a celulares, tabletas y computadoras, con posiciones y estadísticas JJ, JG, JE, JP, GF, GC, DIF y PTS.
- Incluye el logotipo y temporada del torneo cuando están configurados.
- La página se genera en una carpeta elegida por el usuario, junto con instrucciones y los recursos necesarios.
- En esta primera etapa la publicación es manual: al cambiar resultados se vuelve a generar la página. No requiere alojamiento web y puede abrirse localmente en un navegador.
- No modifica la estructura de la base de datos.
