"""Creación y restauración de respaldos completos de Liga 82."""
from datetime import datetime
from pathlib import Path
import os
import shutil
import sqlite3
import tempfile
import zipfile

APP_DIR = Path(__file__).resolve().parent.parent
DB_PATH = APP_DIR / "liga82.db"
LOGOS_DIR = APP_DIR / "logos"


def default_backup_dir():
    path = APP_DIR / "respaldos"
    path.mkdir(parents=True, exist_ok=True)
    return path


def create_backup(connection, destination):
    """Crea un ZIP consistente y evita dejar archivos SQLite abiertos en Windows."""
    destination = Path(destination)
    if destination.exists() and destination.is_dir():
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        destination = destination / f"Liga82_respaldo_{stamp}.zip"
    if destination.suffix.lower() != ".zip":
        destination = destination.with_suffix(".zip")
    destination.parent.mkdir(parents=True, exist_ok=True)

    db_fd, temp_db_name = tempfile.mkstemp(prefix="liga82_db_", suffix=".db")
    os.close(db_fd)
    temp_db = Path(temp_db_name)
    zip_fd, temp_zip_name = tempfile.mkstemp(
        prefix=f".{destination.stem}_", suffix=".tmp", dir=str(destination.parent)
    )
    os.close(zip_fd)
    temp_zip = Path(temp_zip_name)

    try:
        # sqlite3.Connection como context manager NO cierra la conexión al salir.
        # El cierre explícito es indispensable en Windows antes de borrar el .db.
        target = sqlite3.connect(str(temp_db))
        try:
            connection.backup(target)
            check = target.execute("PRAGMA quick_check").fetchone()
            if not check or check[0] != "ok":
                raise sqlite3.DatabaseError("La copia temporal de SQLite no superó quick_check.")
        finally:
            target.close()

        with zipfile.ZipFile(temp_zip, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.write(temp_db, "liga82.db")
            if LOGOS_DIR.is_dir():
                for file in LOGOS_DIR.rglob("*"):
                    if file.is_file():
                        archive.write(file, (Path("logos") / file.relative_to(LOGOS_DIR)).as_posix())

        # Verifica el contenedor antes de publicar el respaldo definitivo.
        with zipfile.ZipFile(temp_zip, "r") as archive:
            bad_file = archive.testzip()
            if bad_file:
                raise zipfile.BadZipFile(f"Error de integridad en el archivo {bad_file}.")
            if "liga82.db" not in archive.namelist():
                raise zipfile.BadZipFile("El ZIP generado no contiene liga82.db.")

        os.replace(temp_zip, destination)
    finally:
        # En Windows ambos archivos deben estar cerrados antes de eliminarlos.
        temp_db.unlink(missing_ok=True)
        temp_zip.unlink(missing_ok=True)

    return str(destination)


def restore_backup(source):
    """Restaura la base de datos y los logotipos, cerrando SQLite antes del reemplazo (Windows)."""
    source = Path(source)
    if not zipfile.is_zipfile(source):
        raise ValueError("El archivo seleccionado no es un respaldo ZIP válido.")

    with zipfile.ZipFile(source, "r") as archive:
        names = set(archive.namelist())
        if "liga82.db" not in names:
            raise ValueError("El respaldo no contiene liga82.db.")
        bad_file = archive.testzip()
        if bad_file:
            raise zipfile.BadZipFile(f"El respaldo está dañado: {bad_file}.")

        fd, temp_db_name = tempfile.mkstemp(prefix="liga82_restore_", suffix=".db", dir=str(APP_DIR))
        os.close(fd)
        temp_db = Path(temp_db_name)
        temp_logos = Path(tempfile.mkdtemp(prefix="liga82_logos_", dir=str(APP_DIR)))
        try:
            temp_db.write_bytes(archive.read("liga82.db"))

            # El context manager de sqlite3 hace COMMIT/ROLLBACK, pero NO cierra
            # la conexión. En Windows eso bloquea el archivo para os.replace/unlink.
            check = sqlite3.connect(str(temp_db))
            try:
                result = check.execute("PRAGMA integrity_check").fetchone()
                if not result or result[0] != "ok":
                    raise sqlite3.DatabaseError("La base de datos del respaldo no superó integrity_check.")
            finally:
                check.close()

            for name in names:
                if not name.startswith("logos/") or name.endswith("/"):
                    continue
                relative = Path(name).relative_to("logos")
                if relative.is_absolute() or ".." in relative.parts:
                    continue
                target = temp_logos / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))

            # La aplicación debe haber cerrado su conexión antes de llamar esta función.
            os.replace(temp_db, DB_PATH)
            if LOGOS_DIR.exists():
                shutil.rmtree(LOGOS_DIR)
            if any(temp_logos.iterdir()):
                os.replace(temp_logos, LOGOS_DIR)
            else:
                shutil.rmtree(temp_logos, ignore_errors=True)
        finally:
            temp_db.unlink(missing_ok=True)
            if temp_logos.exists():
                shutil.rmtree(temp_logos, ignore_errors=True)
