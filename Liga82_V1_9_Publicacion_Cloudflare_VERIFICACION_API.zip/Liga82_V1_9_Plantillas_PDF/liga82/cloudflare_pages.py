"""Publicación directa de la página estática en Cloudflare Pages."""
from pathlib import Path
import base64, ctypes, hashlib, json, mimetypes, os, time, urllib.error, urllib.request

ACCOUNT_ID = "dd6a574e3af5c47e87d12f22379fa413"
PROJECT_NAME = "mastersfutbol"
API = "https://api.cloudflare.com/client/v4"
TOKEN_FILE = Path(__file__).resolve().parent.parent / "cloudflare_token.dat"


def _request(url, token, method="GET", data=None, headers=None):
    h = {"Authorization": f"Bearer {token}", "User-Agent": "Liga82/1.9"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:1200]
        raise RuntimeError(f"Cloudflare respondió HTTP {exc.code}: {detail}") from exc
    except Exception as exc:
        raise RuntimeError(f"No se pudo conectar con Cloudflare: {exc}") from exc
    try:
        result = json.loads(raw.decode("utf-8"))
    except Exception:
        raise RuntimeError("Cloudflare devolvió una respuesta que no se pudo interpretar.")
    if isinstance(result, dict) and result.get("success") is False:
        errors = "; ".join(e.get("message", "Error desconocido") for e in result.get("errors", []))
        raise RuntimeError(errors or "Cloudflare rechazó la solicitud.")
    return result


def _dpapi(data, protect=True):
    if os.name != "nt":
        raise RuntimeError("El almacenamiento protegido del token está disponible en Windows.")
    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", ctypes.c_ulong), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]
    raw = data if isinstance(data, bytes) else data.encode("utf-8")
    buf = ctypes.create_string_buffer(raw)
    inp = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte)))
    out = DATA_BLOB()
    crypt = ctypes.windll.crypt32
    if protect:
        ok = crypt.CryptProtectData(ctypes.byref(inp), "Liga 82 Cloudflare", None, None, None, 0, ctypes.byref(out))
    else:
        ok = crypt.CryptUnprotectData(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out))
    if not ok:
        raise RuntimeError("Windows no pudo proteger o recuperar el token.")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


def save_token(token):
    token = token.strip()
    if not token:
        raise ValueError("Escribe el token de Cloudflare.")
    TOKEN_FILE.write_bytes(_dpapi(token, True))
    try:
        os.chmod(TOKEN_FILE, 0o600)
    except OSError:
        pass


def load_token():
    if not TOKEN_FILE.exists():
        return ""
    return _dpapi(TOKEN_FILE.read_bytes(), False).decode("utf-8")


def test_connection(token):
    url = f"{API}/accounts/{ACCOUNT_ID}/pages/projects/{PROJECT_NAME}"
    result = _request(url, token)
    project = result.get("result", {})
    return project.get("name", PROJECT_NAME)


def _project(token):
    url = f"{API}/accounts/{ACCOUNT_ID}/pages/projects/{PROJECT_NAME}"
    return _request(url, token).get("result", {})


def publish_directory(folder, token):
    root = Path(folder)
    if not root.is_dir() or not (root / "index.html").is_file():
        raise ValueError("Primero genera la página web. La carpeta debe contener index.html.")
    files = {}
    for path in root.rglob("*"):
        if path.is_file() and path.name.lower() != "leeme.txt":
            rel = path.relative_to(root).as_posix()
            content = path.read_bytes()
            digest = hashlib.md5(content).hexdigest()  # Cloudflare Pages identifica assets con hash MD5
            mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            files[rel] = (digest, content, mime)
    if not files:
        raise RuntimeError("No se encontraron archivos para publicar.")

    # Consultar la rama de producción real del proyecto. En Direct Upload,
    # Cloudflare determina Production/Preview usando esta configuración.
    project_before = _project(token)
    production_branch = project_before.get("production_branch") or "main"

    upload_info = _request(f"{API}/accounts/{ACCOUNT_ID}/pages/projects/{PROJECT_NAME}/upload-token", token)
    upload_token = upload_info.get("result", {}).get("jwt") or upload_info.get("result", {}).get("token")
    if not upload_token:
        raise RuntimeError("Cloudflare no entregó el token temporal de carga. Verifica el permiso Pages Edit.")
    hashes = sorted({v[0] for v in files.values()})
    # IMPORTANTE: primero consultar qué recursos faltan. upsert-hashes NO sube
    # archivos; solamente registra hashes como ya cargados. Si se ejecuta antes
    # de check-missing, Cloudflare puede omitir archivos que nunca se enviaron.
    missing_response = _request(f"{API}/pages/assets/check-missing", upload_token, "POST",
                                json.dumps({"hashes": hashes}).encode(), {"Content-Type": "application/json"})
    missing = missing_response.get("result", missing_response)
    if isinstance(missing, dict):
        missing = missing.get("missing", [])
    missing_set = set(missing or [])
    if missing_set:
        by_hash = {}
        for digest, content, mime in files.values():
            if digest in missing_set:
                by_hash[digest] = (content, mime)
        batch = [{"key": digest, "value": base64.b64encode(content).decode("ascii"),
                  "base64": True, "metadata": {"contentType": mime}}
                 for digest, (content, mime) in by_hash.items()]
        _request(f"{API}/pages/assets/upload", upload_token, "POST",
                 json.dumps(batch).encode(), {"Content-Type": "application/json"})

    # Registrar únicamente después de haber subido los recursos que faltaban.
    _request(f"{API}/pages/assets/upsert-hashes", upload_token, "POST",
             json.dumps({"hashes": hashes}).encode(), {"Content-Type": "application/json"})

    manifest = {rel: digest for rel, (digest, _content, _mime) in files.items()}
    boundary = "----Liga82Boundary7MA4YWxkTrZu0gW"
    body = bytearray()
    def field(name, value):
        body.extend(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n".encode())
    field("manifest", json.dumps(manifest, separators=(",", ":")))
    field("branch", production_branch)
    field("commit_message", "Actualización de Tabla General desde Liga 82")
    body.extend(f"--{boundary}--\r\n".encode())
    result = _request(f"{API}/accounts/{ACCOUNT_ID}/pages/projects/{PROJECT_NAME}/deployments", token,
                      "POST", bytes(body), {"Content-Type": f"multipart/form-data; boundary={boundary}"})
    deployment = result.get("result", {})
    deployment_id = deployment.get("id")
    if not deployment_id:
        raise RuntimeError("Cloudflare recibió la solicitud, pero no devolvió el identificador de publicación.")

    # Esperar a que termine el despliegue; el POST por sí solo no significa
    # que el sitio ya esté actualizado.
    deployment_url = f"{API}/accounts/{ACCOUNT_ID}/pages/projects/{PROJECT_NAME}/deployments/{deployment_id}"
    current = deployment
    deadline = time.time() + 120
    while time.time() < deadline:
        stage = current.get("latest_stage", {})
        status = stage.get("status", "")
        if status == "success":
            break
        if status in ("failure", "canceled"):
            raise RuntimeError(f"Cloudflare no pudo completar la publicación (etapa: {stage.get('name', 'desconocida')}, estado: {status}).")
        time.sleep(3)
        current = _request(deployment_url, token).get("result", current)
    else:
        raise RuntimeError("Cloudflare aceptó la publicación, pero sigue procesándola. Espera un minuto y vuelve a comprobar el sitio.")

    # Confirmar que el despliegue quedó como canonical_deployment de producción.
    project_after = _project(token)
    canonical = project_after.get("canonical_deployment") or {}
    if current.get("environment") != "production" or canonical.get("id") != deployment_id:
        env = current.get("environment", "no informado")
        canonical_id = canonical.get("id", "ninguno")
        raise RuntimeError(
            "Cloudflare terminó el envío, pero NO confirmó la actualización del sitio público. "
            f"Rama de producción configurada: {production_branch}. Entorno del envío: {env}. "
            f"ID enviado: {deployment_id}. ID de producción vigente: {canonical_id}. "
            "No se modificó la configuración de tu proyecto. Revisa en Cloudflare Pages cuál es la rama de producción."
        )

    # La URL pública estable es el alias de producción, no la URL única del despliegue.
    aliases = canonical.get("aliases") or current.get("aliases") or []
    public_url = next((u for u in aliases if u.rstrip("/") == f"https://{PROJECT_NAME}.pages.dev"), None)
    public_url = public_url or f"https://{PROJECT_NAME}.pages.dev"

    # La API ya confirmó que el ID del despliegue es el canonical_deployment
    # del proyecto y que su entorno es production. No se consulta el HTML
    # público con urllib: Cloudflare puede responder HTTP 403 a clientes
    # automatizados aunque la página sea accesible desde un navegador. Esa
    # comprobación no es una prueba fiable del contenido y provocaba falsos
    # errores después de una publicación aceptada.
    #
    # Devolvemos la URL estable del proyecto. El ID del despliegue queda
    # disponible para diagnóstico y el usuario puede comprobar la página
    # desde su navegador habitual.
    return public_url
