from datetime import datetime
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter


def export_excel(path, config, teams, matches, standings):
    """Export tournament information to a formatted, editable XLSX workbook."""
    wb = Workbook()
    ws_teams = wb.active
    ws_teams.title = "Equipos"
    ws_fixture = wb.create_sheet("Fixture")
    ws_table = wb.create_sheet("Tabla de posiciones")

    green = "24563C"
    light_green = "EAF2EC"
    white = "FFFFFF"
    thin_gray = Side(style="thin", color="D5DED8")

    def setup_sheet(ws, title, headers, rows, table_name):
        ws.append([title])
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
        ws.cell(1, 1).font = Font(name="Calibri", size=16, bold=True, color=white)
        ws.cell(1, 1).fill = PatternFill("solid", fgColor=green)
        ws.cell(1, 1).alignment = Alignment(vertical="center")
        ws.row_dimensions[1].height = 28
        ws.append([f"{config.get('name') or 'Liga 82'} · Temporada {config.get('season') or ''}"])
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(headers))
        ws.cell(2, 1).font = Font(italic=True, color="547463")
        ws.append(headers)
        for cell in ws[3]:
            cell.font = Font(bold=True, color=white)
            cell.fill = PatternFill("solid", fgColor=green)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for row in rows:
            ws.append(list(row))
        ws.freeze_panes = "A4"
        ws.sheet_view.showGridLines = False
        ws.auto_filter.ref = f"A3:{get_column_letter(len(headers))}{max(3, ws.max_row)}"
        if ws.max_row >= 4:
            ref = f"A3:{get_column_letter(len(headers))}{ws.max_row}"
            table = Table(displayName=table_name, ref=ref)
            table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium4", showFirstColumn=False,
                                                  showLastColumn=False, showRowStripes=True, showColumnStripes=False)
            ws.add_table(table)
        for row in ws.iter_rows(min_row=4):
            for cell in row:
                cell.border = Border(bottom=thin_gray)
                cell.alignment = Alignment(vertical="center", wrap_text=True)
        for col_idx in range(1, len(headers) + 1):
            values = [str(ws.cell(r, col_idx).value or "") for r in range(3, ws.max_row + 1)]
            width = min(max(max((len(v) for v in values), default=10) + 2, 12), 38)
            ws.column_dimensions[get_column_letter(col_idx)].width = width
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.page_setup.orientation = "landscape"
        ws.print_title_rows = "1:3"

    team_headers = ["Equipo", "Localidad", "Encargado", "Cancha predeterminada", "Observaciones", "Ruta del logo"]
    team_rows = [(t.get("name", ""), t.get("city", ""), t.get("manager", ""),
                  t.get("home_field", ""), t.get("notes", ""), t.get("logo_path", "")) for t in teams]
    setup_sheet(ws_teams, "EQUIPOS PARTICIPANTES", team_headers, team_rows, "TablaEquipos")

    fixture_headers = ["Jornada", "Fecha", "Hora", "Local", "Marcador", "Visitante", "Cancha", "Árbitro", "Estado"]
    fixture_rows = []
    for m in sorted(matches, key=lambda x: (x.get("round_no", 0), x.get("match_date") or "", x.get("match_time") or "", x.get("id", 0))):
        score = f"{m['home_goals']} - {m['away_goals']}" if m.get("home_goals") is not None and m.get("away_goals") is not None else ""
        fixture_rows.append((m.get("round_no"), m.get("match_date") or "", m.get("match_time") or "",
                             m.get("home", ""), score, m.get("away", ""), m.get("field_name") or "",
                             m.get("referee_name") or "", m.get("status") or "Pendiente"))
    setup_sheet(ws_fixture, "FIXTURE Y RESULTADOS", fixture_headers, fixture_rows, "TablaFixture")

    standings_headers = ["Posición", "Equipo", "JJ", "JG", "JE", "JP", "GF", "GC", "DIF", "PTS"]
    standings_rows = [(pos, r["team"], r["pj"], r["pg"], r["pe"], r["pp"], r["gf"], r["gc"], r["dif"], r["pts"])
                      for pos, r in enumerate(standings, 1)]
    setup_sheet(ws_table, "TABLA DE POSICIONES", standings_headers, standings_rows, "TablaPosiciones")

    for ws in wb.worksheets:
        ws.sheet_properties.pageSetUpPr.fitToPage = True
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    wb.save(target)
    # Verify the generated workbook can be reopened and contains the expected sheets.
    check = load_workbook(target, read_only=True, data_only=True)
    try:
        if check.sheetnames != ["Equipos", "Fixture", "Tabla de posiciones"]:
            raise OSError("El archivo Excel generado no superó la verificación de hojas.")
    finally:
        check.close()
    return {"teams": len(team_rows), "matches": len(fixture_rows), "standings": len(standings_rows)}
