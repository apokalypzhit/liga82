def round_robin(team_names, legs=1):
    """Return (round_number, home, away) tuples using the circle method."""
    teams = list(team_names)
    if len(teams) < 2:
        return []
    if len(teams) % 2:
        teams.append(None)
    n = len(teams)
    rotation = teams[:]
    result = []
    for round_index in range(n - 1):
        for i in range(n // 2):
            a, b = rotation[i], rotation[n - 1 - i]
            if a is None or b is None:
                continue
            if (round_index + i) % 2:
                a, b = b, a
            result.append((round_index + 1, a, b))
        rotation = [rotation[0]] + [rotation[-1]] + rotation[1:-1]
    if legs == 2:
        first_leg = list(result)
        offset = n - 1
        result.extend((r + offset, away, home) for r, home, away in first_leg)
    return result
