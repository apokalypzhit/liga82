import tkinter as tk
import sqlite3
import shutil
import json
from pathlib import Path
from tkinter import ttk, messagebox, filedialog
from datetime import date, datetime
from .db import Database
from .fixture import round_robin
from .backups import create_backup, restore_backup, default_backup_dir
from .poster import render_poster
from .web_publish import generate_standings_site
from .cloudflare_pages import save_token, load_token, test_connection, publish_directory
import webbrowser

APP_TITLE = "Liga 82 · Administración de torneo"

class Liga82App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1180x760")
        self.minsize(980, 650)
        self.db = Database()
        self.configure(bg="#eef4ef")
        self._style()
        self._build()
        self.refresh_all()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure("TFrame", background="#eef4ef")
        s.configure("Card.TFrame", background="#ffffff")
        s.configure("TLabel", background="#eef4ef", foreground="#173b2b", font=("Segoe UI", 10))
        s.configure("Title.TLabel", font=("Segoe UI", 22, "bold"), foreground="#14532d")
        s.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#547463")
        s.configure("Treeview", rowheight=27, font=("Segoe UI", 9))
        s.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        s.configure("TButton", font=("Segoe UI", 9), padding=6)
        s.configure("Accent.TButton", background="#167447", foreground="white")
        s.map("Accent.TButton", background=[("active", "#105b36")])

    def _build(self):
        header = ttk.Frame(self, padding=(22, 15))
        header.pack(fill="x")
        ttk.Label(header, text="LIGA 82", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="Gestión de torneo · Versión 1.9", style="Sub.TLabel").pack(anchor="w")
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        self.config_tab = ttk.Frame(self.tabs, padding=16)
        self.teams_tab = ttk.Frame(self.tabs, padding=16)
        self.fixture_tab = ttk.Frame(self.tabs, padding=16)
        self.table_tab = ttk.Frame(self.tabs, padding=16)
        self.schedule_tab = ttk.Frame(self.tabs, padding=16)
        self.reports_tab = ttk.Frame(self.tabs, padding=16)
        self.excel_tab = ttk.Frame(self.tabs, padding=16)
        self.backups_tab = ttk.Frame(self.tabs, padding=16)
        self.posters_tab = ttk.Frame(self.tabs, padding=16)
        self.web_tab = ttk.Frame(self.tabs, padding=16)
        self.tabs.add(self.config_tab, text="  Torneo  ")
        self.tabs.add(self.teams_tab, text="  Equipos  ")
        self.tabs.add(self.fixture_tab, text="  Fixture y resultados  ")
        self.tabs.add(self.table_tab, text="  Tabla de posiciones  ")
        self.tabs.add(self.schedule_tab, text="  Canchas y árbitros  ")
        self.tabs.add(self.reports_tab, text="  Reportes PDF  ")
        self.tabs.add(self.excel_tab, text="  Exportar Excel  ")
        self.tabs.add(self.backups_tab, text="  Respaldos  ")
        self.tabs.add(self.posters_tab, text="  Generador de carteles  ")
        self.tabs.add(self.web_tab, text="  Publicación web  ")
        self._build_config()
        self._build_teams()
        self._build_fixture()
        self._build_table()
        self._build_schedule_admin()
        self._build_reports()
        self._build_excel_export()
        self._build_backups()
        self._build_posters()
        self._build_web_publish()

    def _build_config(self):
        f = self.config_tab
        ttk.Label(f, text="Configuración del torneo", style="Title.TLabel").pack(anchor="w", pady=(0, 16))
        form = ttk.Frame(f, style="Card.TFrame", padding=20)
        form.pack(fill="x", anchor="n")
        self.t_name = tk.StringVar()
        self.t_season = tk.StringVar(value=str(date.today().year))
        self.t_points_win = tk.StringVar(value="3")
        self.t_points_draw = tk.StringVar(value="1")
        self.t_points_loss = tk.StringVar(value="0")
        self.t_rounds = tk.StringVar(value="Una vuelta")
        self.t_logo = tk.StringVar(value="")
        fields = [
            ("Nombre del torneo", self.t_name, 0, 0),
            ("Temporada", self.t_season, 0, 2),
            ("Puntos por victoria", self.t_points_win, 1, 0),
            ("Puntos por empate", self.t_points_draw, 1, 2),
            ("Puntos por derrota", self.t_points_loss, 2, 0),
        ]
        for label, var, row, col in fields:
            box = ttk.Frame(form, style="Card.TFrame")
            box.grid(row=row, column=col, sticky="ew", padx=(0, 22), pady=9)
            ttk.Label(box, text=label).pack(anchor="w")
            ttk.Entry(box, textvariable=var, width=34).pack(anchor="w", pady=(4, 0))
        form.columnconfigure(0, weight=1)
        form.columnconfigure(2, weight=1)
        box = ttk.Frame(form, style="Card.TFrame")
        box.grid(row=2, column=2, sticky="ew", padx=(0, 22), pady=9)
        ttk.Label(box, text="Sistema de competencia").pack(anchor="w")
        ttk.Combobox(box, textvariable=self.t_rounds, values=["Una vuelta", "Dos vueltas"], state="readonly", width=31).pack(anchor="w", pady=(4, 0))
        logo_row = ttk.Frame(form, style="Card.TFrame")
        logo_row.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(8, 2))
        ttk.Label(logo_row, text="Logotipo del torneo (opcional)").pack(anchor="w")
        logo_controls = ttk.Frame(logo_row, style="Card.TFrame")
        logo_controls.pack(fill="x", pady=(4, 0))
        ttk.Entry(logo_controls, textvariable=self.t_logo, state="readonly", width=65).pack(side="left", padx=(0, 8))
        ttk.Button(logo_controls, text="Seleccionar logo…", command=self.choose_tournament_logo).pack(side="left")
        ttk.Button(logo_controls, text="Quitar logo", command=lambda: self.t_logo.set("")).pack(side="left", padx=6)
        ttk.Button(f, text="Guardar configuración", style="Accent.TButton", command=self.save_config).pack(anchor="w", pady=16)
        self.config_status = ttk.Label(f, text="Los cambios se guardan localmente en la base de datos Liga 82.")
        self.config_status.pack(anchor="w")


    def _build_web_publish(self):
        ttk.Label(self.web_tab, text="Publicación web", style="Title.TLabel").pack(anchor="w", pady=(0, 8))
        ttk.Label(self.web_tab, text="Genera una página independiente con la Tabla General del torneo. No necesitas contratar alojamiento todavía: podrás abrirla en tu computadora y publicarla más adelante.", style="Sub.TLabel", wraplength=900).pack(anchor="w", pady=(0, 18))
        card = ttk.LabelFrame(self.web_tab, text="Página de Tabla General", padding=18)
        card.pack(fill="x", anchor="n")
        ttk.Label(card, text="La página incluirá el logotipo del torneo (si está configurado), temporada, posiciones y estadísticas JJ, JG, JE, JP, GF, GC, DIF y PTS.", wraplength=850).pack(anchor="w", pady=(0, 12))
        actions = ttk.Frame(card)
        actions.pack(anchor="w")
        ttk.Button(actions, text="Generar página web…", style="Accent.TButton", command=self.export_standings_site).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Actualizar página guardada", command=self.update_standings_site).pack(side="left", padx=8)
        ttk.Button(actions, text="Cambiar carpeta…", command=self.change_standings_site_folder).pack(side="left", padx=8)
        saved_folder = self.db.get_setting("web_standings_folder", "")
        self.web_folder_label = ttk.Label(card, text=f"Carpeta configurada: {saved_folder or 'Todavía no configurada'}", wraplength=850)
        self.web_folder_label.pack(anchor="w", pady=(14, 0))
        ttk.Label(self.web_tab, text="Después de capturar nuevos resultados, usa ‘Actualizar página guardada’. Liga 82 conservará el diseño y reemplazará los datos de la tabla en la misma carpeta.", style="Sub.TLabel", wraplength=900).pack(anchor="w", pady=16)

        cloud = ttk.LabelFrame(self.web_tab, text="Publicación en Internet · Cloudflare Pages", padding=18)
        cloud.pack(fill="x", anchor="n", pady=(4, 0))
        ttk.Label(cloud, text="Proyecto: mastersfutbol.pages.dev  |  Cuenta configurada para esta instalación", style="Sub.TLabel").pack(anchor="w", pady=(0, 8))
        token_row = ttk.Frame(cloud)
        token_row.pack(fill="x")
        ttk.Label(token_row, text="API Token:").pack(side="left", padx=(0, 8))
        self.cloudflare_token_var = tk.StringVar()
        self.cloudflare_token_entry = ttk.Entry(token_row, textvariable=self.cloudflare_token_var, show="•", width=52)
        self.cloudflare_token_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ttk.Button(token_row, text="Guardar token", command=self.save_cloudflare_token).pack(side="left")
        cloud_actions = ttk.Frame(cloud)
        cloud_actions.pack(anchor="w", pady=(12, 0))
        ttk.Button(cloud_actions, text="Probar conexión", command=self.test_cloudflare_connection).pack(side="left", padx=(0, 8))
        ttk.Button(cloud_actions, text="Publicar / actualizar ahora", style="Accent.TButton", command=self.publish_cloudflare_site).pack(side="left", padx=8)
        self.cloudflare_status = ttk.Label(cloud, text="Token no cargado. Pégalo aquí y pulsa ‘Guardar token’.", style="Sub.TLabel", wraplength=850)
        self.cloudflare_status.pack(anchor="w", pady=(12, 0))
        try:
            self.cloudflare_token_var.set(load_token())
            if self.cloudflare_token_var.get():
                self.cloudflare_status.configure(text="Token guardado localmente con protección de Windows.")
        except Exception:
            self.cloudflare_status.configure(text="No se pudo recuperar el token guardado. Puedes introducirlo nuevamente.")
        ttk.Label(cloud, text="El token se cifra con Windows DPAPI en esta computadora. No se incluye en la base de datos ni en los ZIP del proyecto.", style="Sub.TLabel", wraplength=850).pack(anchor="w", pady=(8, 0))

    def save_cloudflare_token(self):
        token = self.cloudflare_token_var.get().strip()
        try:
            save_token(token)
            self.cloudflare_status.configure(text="Token guardado localmente con protección de Windows.")
            messagebox.showinfo("Token guardado", "El token quedó guardado de forma protegida en esta computadora.", parent=self)
        except Exception as exc:
            messagebox.showerror("No se pudo guardar el token", str(exc), parent=self)

    def _cloudflare_token(self):
        token = self.cloudflare_token_var.get().strip()
        if not token:
            try:
                token = load_token()
            except Exception:
                token = ""
        if not token:
            messagebox.showwarning("Falta el token", "Pega tu API Token de Cloudflare y pulsa ‘Guardar token’.", parent=self)
            return ""
        return token

    def test_cloudflare_connection(self):
        token = self._cloudflare_token()
        if not token:
            return
        self.cloudflare_status.configure(text="Comprobando conexión con Cloudflare…")
        self.update_idletasks()
        try:
            project = test_connection(token)
            self.cloudflare_status.configure(text=f"Conexión correcta. Proyecto encontrado: {project}.")
            messagebox.showinfo("Conexión correcta", f"Liga 82 pudo comunicarse con Cloudflare.\nProyecto: {project}", parent=self)
        except Exception as exc:
            self.cloudflare_status.configure(text="No se pudo validar la conexión.")
            messagebox.showerror("Error de conexión", str(exc), parent=self)

    def publish_cloudflare_site(self):
        token = self._cloudflare_token()
        if not token:
            return
        folder = self.db.get_setting("web_standings_folder", "")
        if not folder or not Path(folder).is_dir():
            folder = filedialog.askdirectory(parent=self, title="Selecciona la carpeta donde se generará la página de Liga 82")
            if not folder:
                return
            self.db.set_setting("web_standings_folder", folder)
        try:
            generate_standings_site(self.db.get_config(), self.db.get_standings(), folder)
            self.web_folder_label.configure(text=f"Carpeta configurada: {folder}")
            self.cloudflare_status.configure(text="Preparando archivos y enviando publicación a Cloudflare…")
            self.update_idletasks()
            url = publish_directory(folder, token)
            self.cloudflare_status.configure(text=f"Despliegue de producción confirmado. Sitio público: {url}")
            if messagebox.askyesno("Publicación exitosa", f"Cloudflare confirmó que el nuevo despliegue quedó activo en producción. Abre el sitio para comprobar la tabla.\n\n{url}\n\n¿Deseas abrirla en tu navegador?", parent=self):
                webbrowser.open(url if url.startswith("http") else "https://" + url)
        except Exception as exc:
            self.cloudflare_status.configure(text="La publicación no se completó. Revisa el mensaje de error.")
            messagebox.showerror("Error al publicar", str(exc), parent=self)

    def _generate_web_page_in(self, folder, ask_open=False):
        page = generate_standings_site(self.db.get_config(), self.db.get_standings(), folder)
        self.db.set_setting("web_standings_folder", str(Path(folder)))
        self.web_folder_label.configure(text=f"Carpeta configurada: {folder}")
        messagebox.showinfo("Página web actualizada", f"La página de Tabla General se generó correctamente.\n\nArchivo: {page}", parent=self)
        if ask_open and messagebox.askyesno("Abrir página", "¿Deseas abrir la página en tu navegador?", parent=self):
            webbrowser.open(page.as_uri())

    def export_standings_site(self):
        folder = filedialog.askdirectory(parent=self, title="Selecciona dónde guardar la página web de Liga 82")
        if not folder:
            return
        try:
            self._generate_web_page_in(folder, ask_open=True)
        except Exception as exc:
            messagebox.showerror("Error al generar página", f"No fue posible generar la página web:\n{exc}", parent=self)

    def update_standings_site(self):
        folder = self.db.get_setting("web_standings_folder", "")
        if not folder or not Path(folder).is_dir():
            messagebox.showwarning("Carpeta no configurada", "Primero genera la página web y selecciona una carpeta válida.", parent=self)
            return
        try:
            self._generate_web_page_in(folder, ask_open=False)
        except Exception as exc:
            messagebox.showerror("Error al actualizar página", f"No fue posible actualizar la página web:\n{exc}", parent=self)

    def change_standings_site_folder(self):
        folder = filedialog.askdirectory(parent=self, title="Selecciona la nueva carpeta de publicación")
        if not folder:
            return
        try:
            self._generate_web_page_in(folder, ask_open=False)
        except Exception as exc:
            messagebox.showerror("Error al cambiar carpeta", f"No fue posible generar la página web en esa carpeta:\n{exc}", parent=self)

    def _build_posters(self):
        ttk.Label(self.posters_tab, text="Generador de carteles", style="Title.TLabel").pack(anchor="w", pady=(0, 8))
        ttk.Label(self.posters_tab, text="Crea publicaciones verticales para Facebook a partir de los partidos registrados. Formato 1080 × 1350 px.", style="Sub.TLabel", wraplength=950).pack(anchor="w", pady=(0, 14))
        controls = ttk.LabelFrame(self.posters_tab, text="Jornada y fondo", padding=14)
        controls.pack(fill="x", anchor="n")
        row = ttk.Frame(controls); row.pack(fill="x")
        ttk.Label(row, text="Jornada:").pack(side="left")
        self.poster_round = tk.StringVar(value="1")
        self.poster_round_box = ttk.Combobox(row, textvariable=self.poster_round, state="readonly", width=12)
        self.poster_round_box.pack(side="left", padx=8)
        self.poster_bg_path = tk.StringVar(value=self.db.get_setting("poster_background", ""))
        ttk.Button(row, text="Cambiar fondo…", command=self.choose_poster_background).pack(side="left", padx=(12,5))
        ttk.Button(row, text="Usar fondo original", command=self.reset_poster_background).pack(side="left")
        self.poster_bg_label = ttk.Label(controls, text=self.poster_bg_path.get() or "Fondo original de estadio", style="Sub.TLabel")
        self.poster_bg_label.pack(anchor="w", pady=(8,0))
        actions=ttk.Frame(self.posters_tab); actions.pack(fill="x", pady=12)
        ttk.Button(actions, text="Administrar patrocinadores…", command=self.manage_poster_sponsors).pack(side="left")
        ttk.Button(actions, text="Generar vista previa", style="Accent.TButton", command=self.preview_poster).pack(side="left", padx=8)
        ttk.Button(actions, text="Exportar JPG / PNG…", command=self.export_poster).pack(side="left")
        preview_tools = ttk.Frame(self.posters_tab)
        preview_tools.pack(fill="x", pady=(4, 0))
        ttk.Label(preview_tools, text="Zoom:").pack(side="left")
        self.poster_zoom = tk.IntVar(value=50)
        for value in (25, 50, 75, 100, 125, 150):
            ttk.Button(preview_tools, text=f"{value}%", width=5,
                       command=lambda v=value: self._set_poster_zoom(v)).pack(side="left", padx=2)
        self.poster_zoom_label = ttk.Label(preview_tools, text="50%")
        self.poster_zoom_label.pack(side="left", padx=8)
        preview_frame = ttk.Frame(self.posters_tab)
        preview_frame.pack(fill="both", expand=True, pady=6)
        self.poster_preview_canvas = tk.Canvas(preview_frame, background="#202820", highlightthickness=0)
        self.poster_preview_canvas.grid(row=0, column=0, sticky="nsew")
        preview_vsb = ttk.Scrollbar(preview_frame, orient="vertical", command=self.poster_preview_canvas.yview)
        preview_vsb.grid(row=0, column=1, sticky="ns")
        preview_hsb = ttk.Scrollbar(preview_frame, orient="horizontal", command=self.poster_preview_canvas.xview)
        preview_hsb.grid(row=1, column=0, sticky="ew")
        self.poster_preview_canvas.configure(yscrollcommand=preview_vsb.set, xscrollcommand=preview_hsb.set)
        preview_frame.rowconfigure(0, weight=1)
        preview_frame.columnconfigure(0, weight=1)
        self.poster_preview_canvas.create_text(20, 20, anchor="nw", fill="white",
                                               text="La vista previa aparecerá aquí.", tags="placeholder")
        self._poster_image_ref=None
        self._poster_last_image=None
        self._refresh_poster_rounds()

    def _refresh_poster_rounds(self):
        rounds=sorted({m['round_no'] for m in self.db.get_matches()})
        vals=[str(x) for x in rounds] or ["1"]
        self.poster_round_box["values"]=vals
        if self.poster_round.get() not in vals: self.poster_round.set(vals[0])

    def _poster_assets_dir(self):
        folder=Path(__file__).resolve().parent.parent / "logos" / "poster_assets"
        folder.mkdir(parents=True,exist_ok=True)
        (folder/"sponsors").mkdir(exist_ok=True)
        return folder

    def choose_poster_background(self):
        src=filedialog.askopenfilename(parent=self,title="Seleccionar fondo del cartel",filetypes=[("Imágenes","*.png *.jpg *.jpeg *.webp *.bmp")])
        if not src: return
        try:
            source=Path(src); dest=self._poster_assets_dir()/f"background{source.suffix.lower()}"
            shutil.copy2(source,dest)
            self.poster_bg_path.set(str(dest)); self.db.set_setting("poster_background",str(dest))
            self.poster_bg_label.config(text=str(dest))
        except Exception as exc: messagebox.showerror("Fondo",f"No se pudo copiar la imagen:\n{exc}",parent=self)

    def reset_poster_background(self):
        self.poster_bg_path.set(""); self.db.set_setting("poster_background","")
        self.poster_bg_label.config(text="Fondo original de estadio")

    def _get_poster_sponsors(self):
        try: return json.loads(self.db.get_setting("poster_sponsors","[]"))
        except (ValueError,TypeError): return []

    def _save_poster_sponsors(self, sponsors):
        self.db.set_setting("poster_sponsors",json.dumps(sponsors,ensure_ascii=False))

    def manage_poster_sponsors(self):
        win = tk.Toplevel(self)
        win.title("Administrar patrocinadores")
        win.geometry("900x620")
        win.minsize(720, 480)
        win.resizable(True, True)
        try:
            win.state("zoomed")
        except tk.TclError:
            pass
        win.transient(self)
        win.grab_set()

        ttk.Label(win, text="Logotipos de patrocinadores", font=("Segoe UI", 15, "bold")).pack(
            anchor="w", padx=16, pady=(14, 5)
        )
        ttk.Label(
            win,
            text=("1. Pulsa Agregar para incorporar archivos.  2. Selecciona un patrocinador "
                  "para subirlo, bajarlo, activarlo o eliminarlo.  3. Pulsa Guardar y cerrar. "
                  "Después genera nuevamente la vista previa para ver los cambios."),
            wraplength=680,
        ).pack(anchor="w", padx=16, pady=(0, 10))

        box = ttk.Frame(win, padding=12)
        box.pack(fill="both", expand=True)
        tree = ttk.Treeview(box, columns=("name", "state"), show="headings", height=11, selectmode="browse")
        tree.heading("name", text="Patrocinador / archivo")
        tree.heading("state", text="Aparecerá en cartel")
        tree.column("name", width=440)
        tree.column("state", width=150, anchor="center")
        tree.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(box, orient="vertical", command=tree.yview)
        sb.pack(side="right", fill="y")
        tree.configure(yscrollcommand=sb.set)

        sponsors = self._get_poster_sponsors()
        status = tk.StringVar(value="")

        def refresh(select_index=None):
            tree.delete(*tree.get_children())
            for i, item in enumerate(sponsors):
                exists = bool(item.get("path") and Path(item["path"]).is_file())
                state = "Sí" if item.get("active", True) and exists else ("No" if not item.get("active", True) else "Archivo no encontrado")
                tree.insert("", "end", iid=str(i), values=(item.get("name", Path(item.get("path", "")).name), state))
            if select_index is not None and 0 <= select_index < len(sponsors):
                tree.selection_set(str(select_index))
                tree.focus(str(select_index))
            active_count = sum(1 for x in sponsors if x.get("active", True) and x.get("path") and Path(x["path"]).is_file())
            status.set(f"{len(sponsors)} logotipo(s) registrados · {active_count} aparecerán en el cartel")

        def selected():
            selection = tree.selection()
            return int(selection[0]) if selection else None

        def add():
            files = filedialog.askopenfilenames(
                parent=win, title="Agregar logotipos de patrocinadores",
                filetypes=[("Imágenes", "*.png *.jpg *.jpeg *.webp *.bmp")],
            )
            last = None
            for src in files:
                source = Path(src)
                dest = self._poster_assets_dir() / "sponsors" / source.name
                base, ext, number = dest.stem, dest.suffix, 2
                while dest.exists():
                    dest = dest.with_name(f"{base}_{number}{ext}")
                    number += 1
                try:
                    shutil.copy2(source, dest)
                    sponsors.append({"name": source.stem, "path": str(dest), "active": True})
                    last = len(sponsors) - 1
                except Exception as exc:
                    messagebox.showerror("Patrocinadores", f"No se pudo copiar {source.name}:\n{exc}", parent=win)
            refresh(last)

        def remove():
            i = selected()
            if i is not None:
                sponsors.pop(i)
                refresh(min(i, len(sponsors) - 1))

        def toggle():
            i = selected()
            if i is not None:
                sponsors[i]["active"] = not sponsors[i].get("active", True)
                refresh(i)

        def move(delta):
            i = selected()
            j = i + delta if i is not None else -1
            if i is not None and 0 <= j < len(sponsors):
                sponsors[i], sponsors[j] = sponsors[j], sponsors[i]
                refresh(j)

        buttons = ttk.Frame(win, padding=(12, 0))
        buttons.pack(fill="x")
        for label, command in [
            ("Agregar logotipos…", add), ("Eliminar", remove),
            ("Activar / desactivar", toggle), ("Subir ↑", lambda: move(-1)),
            ("Bajar ↓", lambda: move(1)),
        ]:
            ttk.Button(buttons, text=label, command=command).pack(side="left", padx=3, pady=5)

        ttk.Label(win, textvariable=status).pack(anchor="w", padx=16, pady=(5, 0))

        def save():
            self._save_poster_sponsors(sponsors)
            win.destroy()
            messagebox.showinfo(
                "Patrocinadores guardados",
                "Los logotipos quedaron guardados. Pulsa «Generar vista previa» para verlos en el cartel.",
                parent=self,
            )

        ttk.Button(buttons, text="Guardar y cerrar", style="Accent.TButton", command=save).pack(
            side="right", padx=6, pady=5
        )
        refresh()

    def _build_poster_image(self):
        if not self.poster_round.get(): raise ValueError("Selecciona una jornada.")
        cfg=self.db.get_config() or {}
        matches=[m for m in self.db.get_matches() if m['round_no']==int(self.poster_round.get())]
        return render_poster(cfg,int(self.poster_round.get()),matches,self.db.get_teams(),self._get_poster_sponsors(),self.poster_bg_path.get() or None)

    def _set_poster_zoom(self, value):
        self.poster_zoom.set(int(value))
        self._render_poster_preview()

    def _render_poster_preview(self):
        if self._poster_last_image is None:
            return
        from PIL import Image, ImageTk
        percent = max(10, min(200, int(self.poster_zoom.get())))
        w = max(1, int(self._poster_last_image.width * percent / 100))
        h = max(1, int(self._poster_last_image.height * percent / 100))
        preview = self._poster_last_image.resize((w, h), Image.Resampling.LANCZOS)
        self._poster_image_ref = ImageTk.PhotoImage(preview)
        canvas = self.poster_preview_canvas
        canvas.delete("all")
        canvas.create_image(10, 10, anchor="nw", image=self._poster_image_ref)
        canvas.configure(scrollregion=(0, 0, w + 20, h + 20))
        self.poster_zoom_label.config(text=f"{percent}%")
        canvas.xview_moveto(0)
        canvas.yview_moveto(0)

    def preview_poster(self):
        try:
            self._poster_last_image = self._build_poster_image()
            self._render_poster_preview()
        except Exception as exc:
            messagebox.showerror("Generador de carteles",f"No se pudo generar la vista previa:\n{exc}",parent=self)

    def export_poster(self):
        try:
            from PIL import Image
            ext=filedialog.asksaveasfilename(parent=self,title="Exportar cartel",defaultextension=".jpg",filetypes=[("Imagen JPG","*.jpg"),("Imagen PNG","*.png")],initialfile=f"Liga82_Jornada_{self.poster_round.get()}")
            if not ext: return
            im=self._build_poster_image()
            if Path(ext).suffix.lower()==".png": im.save(ext,"PNG",optimize=True)
            else: im.save(ext,"JPEG",quality=94,optimize=True)
            messagebox.showinfo("Cartel generado",f"La imagen se guardó correctamente:\n{ext}",parent=self)
        except Exception as exc: messagebox.showerror("Generador de carteles",f"No se pudo exportar el cartel:\n{exc}",parent=self)

    def _build_backups(self):
        ttk.Label(self.backups_tab, text="Respaldos y restauración", style="Title.TLabel").pack(anchor="w", pady=(0, 14))
        panel = ttk.LabelFrame(self.backups_tab, text="Copia de seguridad", padding=18)
        panel.pack(fill="x", anchor="n")
        ttk.Label(panel, text="Un respaldo incluye la base de datos del torneo y la carpeta de logotipos.", wraplength=850).pack(anchor="w", pady=(0, 12))
        ttk.Button(panel, text="Crear respaldo ahora…", style="Accent.TButton", command=self.create_manual_backup).pack(anchor="w", pady=(0, 12))
        self.auto_backup_var = tk.BooleanVar(value=self.db.get_setting("auto_backup_on_close", "1") == "1")
        ttk.Checkbutton(panel, text="Crear automáticamente un respaldo al cerrar Liga 82", variable=self.auto_backup_var, command=self.save_backup_preference).pack(anchor="w", pady=(0, 12))
        ttk.Label(panel, text=f"Los respaldos automáticos se guardan en: {default_backup_dir()}", style="Sub.TLabel", wraplength=900).pack(anchor="w")
        restore_box = ttk.LabelFrame(self.backups_tab, text="Restaurar una copia", padding=18)
        restore_box.pack(fill="x", anchor="n", pady=16)
        ttk.Label(restore_box, text="La restauración reemplaza los datos actuales. Antes de hacerlo, Liga 82 crea automáticamente un respaldo de seguridad del estado actual.", wraplength=850).pack(anchor="w", pady=(0, 12))
        ttk.Button(restore_box, text="Seleccionar respaldo para restaurar…", command=self.restore_from_backup).pack(anchor="w")
        self.backup_status = ttk.Label(self.backups_tab, text="Los respaldos no modifican el torneo activo.", style="Sub.TLabel", wraplength=900)
        self.backup_status.pack(anchor="w", pady=8)

    def save_backup_preference(self):
        self.db.set_setting("auto_backup_on_close", "1" if self.auto_backup_var.get() else "0")

    def create_manual_backup(self):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        destination = filedialog.asksaveasfilename(
            title="Guardar respaldo de Liga 82",
            defaultextension=".zip",
            initialfile=f"Liga82_respaldo_{stamp}.zip",
            filetypes=[("Respaldo ZIP", "*.zip")])
        if not destination:
            return
        try:
            create_backup(self.db.conn, destination)
            self.backup_status.config(text=f"Respaldo creado correctamente: {destination}")
            messagebox.showinfo("Respaldo creado", "La base de datos y los logotipos se guardaron correctamente.", parent=self)
        except Exception as exc:
            messagebox.showerror("Error al crear respaldo", str(exc), parent=self)

    def restore_from_backup(self):
        source = filedialog.askopenfilename(title="Seleccionar respaldo de Liga 82", filetypes=[("Respaldo ZIP", "*.zip")])
        if not source:
            return
        if not messagebox.askyesno("Confirmar restauración", "Se reemplazarán los datos actuales por los del respaldo. Antes se creará una copia de seguridad del estado actual. ¿Deseas continuar?", icon="warning", parent=self):
            return
        try:
            safety_path = create_backup(self.db.conn, default_backup_dir())
            self.db.close()
            try:
                restore_backup(source)
            except Exception:
                # Reabrir la base de datos actual si la restauración no se completa.
                self.db = Database()
                raise
            self.db = Database()
            self.refresh_all()
            self.backup_status.config(text=f"Respaldo restaurado. Copia de seguridad previa: {safety_path}")
            messagebox.showinfo("Restauración completada", "El respaldo se restauró correctamente.", parent=self)
        except Exception as exc:
            messagebox.showerror("No se pudo restaurar", str(exc), parent=self)

    def _build_teams(self):
        top = ttk.Frame(self.teams_tab)
        top.pack(fill="x")
        ttk.Label(top, text="Equipos participantes", style="Title.TLabel").pack(side="left")
        self.team_name = tk.StringVar()
        self.team_city = tk.StringVar()
        form = ttk.Frame(self.teams_tab, style="Card.TFrame", padding=12)
        form.pack(fill="x", pady=14)
        ttk.Label(form, text="Nombre del equipo").grid(row=0, column=0, sticky="w")
        ttk.Entry(form, textvariable=self.team_name, width=32).grid(row=1, column=0, padx=(0, 12), sticky="w")
        ttk.Label(form, text="Localidad (opcional)").grid(row=0, column=1, sticky="w")
        ttk.Entry(form, textvariable=self.team_city, width=28).grid(row=1, column=1, padx=(0, 12), sticky="w")
        ttk.Button(form, text="Agregar equipo", style="Accent.TButton", command=self.add_team).grid(row=1, column=2)
        self.team_tree = ttk.Treeview(self.teams_tab, columns=("id", "name", "city"), show="headings", height=15)
        for col, title, width in [("id", "#", 60), ("name", "Equipo", 400), ("city", "Localidad", 250)]:
            self.team_tree.heading(col, text=title)
            self.team_tree.column(col, width=width, anchor="center" if col == "id" else "w")
        self.team_tree.pack(fill="both", expand=True)
        bottom = ttk.Frame(self.teams_tab)
        bottom.pack(fill="x", pady=10)
        ttk.Button(bottom, text="Editar ficha del equipo", command=self.edit_team_profile).pack(side="left")
        ttk.Button(bottom, text="Eliminar equipo seleccionado", command=self.delete_team).pack(side="left", padx=8)
        self.team_count = ttk.Label(bottom, text="0 / 20 equipos")
        self.team_count.pack(side="right")

    def _build_fixture(self):
        top = ttk.Frame(self.fixture_tab)
        top.pack(fill="x")
        ttk.Label(top, text="Fixture y captura de resultados", style="Title.TLabel").pack(side="left")
        ttk.Button(top, text="Generar fixture", style="Accent.TButton", command=self.generate_fixture).pack(side="right")
        ttk.Label(self.fixture_tab, text="Selecciona un partido y pulsa «Capturar / editar resultado». Solo los partidos marcados como Jugado cuentan para la tabla.", style="Sub.TLabel").pack(anchor="w", pady=(8, 8))
        filters = ttk.Frame(self.fixture_tab, style="Card.TFrame", padding=10)
        filters.pack(fill="x", pady=(0, 10))
        self.filter_round = tk.StringVar(value="Todas")
        self.filter_team = tk.StringVar(value="Todos")
        self.filter_status = tk.StringVar(value="Todos")
        ttk.Label(filters, text="Jornada").pack(side="left")
        self.round_filter_box = ttk.Combobox(filters, textvariable=self.filter_round, state="readonly", width=12)
        self.round_filter_box.pack(side="left", padx=(5, 14))
        ttk.Label(filters, text="Equipo").pack(side="left")
        self.team_filter_box = ttk.Combobox(filters, textvariable=self.filter_team, state="readonly", width=24)
        self.team_filter_box.pack(side="left", padx=(5, 14))
        ttk.Label(filters, text="Estado").pack(side="left")
        self.status_filter_box = ttk.Combobox(filters, textvariable=self.filter_status, state="readonly", width=18,
            values=["Todos", "Pendiente", "Programado", "Jugado", "Suspendido", "Reprogramado"])
        self.status_filter_box.pack(side="left", padx=(5, 10))
        ttk.Button(filters, text="Limpiar filtros", command=self.clear_fixture_filters).pack(side="left")
        for box in (self.round_filter_box, self.team_filter_box, self.status_filter_box):
            box.bind("<<ComboboxSelected>>", lambda _e: self.refresh_fixture())
        cols = ("round", "date", "time", "home", "score", "away", "field", "referee", "status")
        self.match_tree = ttk.Treeview(self.fixture_tab, columns=cols, show="headings", height=17)
        for col, title, width in [
            ("round", "Jornada", 65), ("date", "Fecha", 95), ("time", "Hora", 65),
            ("home", "Local", 190), ("score", "Marcador", 85), ("away", "Visitante", 190),
            ("field", "Cancha", 130), ("referee", "Árbitro", 130), ("status", "Estado", 115)
        ]:
            self.match_tree.heading(col, text=title)
            self.match_tree.column(col, width=width, anchor="center" if col in ("round", "score", "status") else "w")
        self.match_tree.pack(fill="both", expand=True)
        actions = ttk.Frame(self.fixture_tab)
        actions.pack(fill="x", pady=10)
        ttk.Button(actions, text="Capturar / editar resultado", style="Accent.TButton", command=self.edit_result).pack(side="left")
        ttk.Button(actions, text="Programar partido", command=self.schedule_selected_match).pack(side="left", padx=8)
        ttk.Button(actions, text="Limpiar resultado", command=self.clear_result).pack(side="left", padx=8)
        self.fixture_status = ttk.Label(actions, text="0 partidos")
        self.fixture_status.pack(side="right")

    def _build_schedule_admin(self):
        ttk.Label(self.schedule_tab, text="Administración de canchas y árbitros", style="Title.TLabel").pack(anchor="w", pady=(0, 14))
        panels = ttk.Frame(self.schedule_tab)
        panels.pack(fill="both", expand=True)
        left = ttk.LabelFrame(panels, text="Canchas", padding=12)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        right = ttk.LabelFrame(panels, text="Árbitros", padding=12)
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))
        self.field_name = tk.StringVar(); self.field_address = tk.StringVar()
        ttk.Label(left, text="Nombre de la cancha").pack(anchor="w")
        ttk.Entry(left, textvariable=self.field_name).pack(fill="x", pady=(2, 6))
        ttk.Label(left, text="Dirección / ubicación (opcional)").pack(anchor="w")
        ttk.Entry(left, textvariable=self.field_address).pack(fill="x", pady=(2, 8))
        ttk.Button(left, text="Agregar cancha", style="Accent.TButton", command=self.add_field).pack(anchor="w")
        self.field_tree = ttk.Treeview(left, columns=("name", "address"), show="headings", height=13)
        self.field_tree.heading("name", text="Cancha"); self.field_tree.heading("address", text="Ubicación")
        self.field_tree.column("name", width=180); self.field_tree.column("address", width=220)
        self.field_tree.pack(fill="both", expand=True, pady=8)
        ttk.Button(left, text="Eliminar cancha seleccionada", command=self.delete_field).pack(anchor="w")
        self.ref_name = tk.StringVar(); self.ref_phone = tk.StringVar()
        ttk.Label(right, text="Nombre del árbitro").pack(anchor="w")
        ttk.Entry(right, textvariable=self.ref_name).pack(fill="x", pady=(2, 6))
        ttk.Label(right, text="Teléfono (opcional)").pack(anchor="w")
        ttk.Entry(right, textvariable=self.ref_phone).pack(fill="x", pady=(2, 8))
        ttk.Button(right, text="Agregar árbitro", style="Accent.TButton", command=self.add_referee).pack(anchor="w")
        self.ref_tree = ttk.Treeview(right, columns=("name", "phone"), show="headings", height=13)
        self.ref_tree.heading("name", text="Árbitro"); self.ref_tree.heading("phone", text="Teléfono")
        self.ref_tree.column("name", width=180); self.ref_tree.column("phone", width=150)
        self.ref_tree.pack(fill="both", expand=True, pady=8)
        ttk.Button(right, text="Eliminar árbitro seleccionado", command=self.delete_referee).pack(anchor="w")
        ttk.Label(self.schedule_tab, text="Selecciona un partido en Fixture y resultados para asignarle fecha, hora, cancha y árbitro. Se detectan cruces de horario considerando la duración del encuentro.", style="Sub.TLabel", wraplength=950).pack(anchor="w", pady=(12, 0))

    def _build_reports(self):
        ttk.Label(self.reports_tab, text="Reportes PDF", style="Title.TLabel").pack(anchor="w", pady=(0, 14))
        box = ttk.LabelFrame(self.reports_tab, text="Criterios del reporte", padding=16)
        box.pack(fill="x", anchor="n")
        self.report_type = tk.StringVar(value="Reporte de jornada")
        self.report_round = tk.StringVar(value="1")
        self.report_orientation = tk.StringVar(value="Vertical")
        self.report_scope = tk.StringVar(value="Por jornada")
        self.report_design = tk.StringVar(value=self.db.get_setting("report_design", "Fútbol clásico"))
        self.report_status_vars = {name: tk.BooleanVar(value=(name == "Jugado")) for name in ["Pendiente", "Programado", "Jugado", "Suspendido", "Reprogramado"]}
        ttk.Label(box, text="Tipo de reporte").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.report_type_box = ttk.Combobox(box, textvariable=self.report_type, state="readonly", width=29,
            values=["Reporte de jornada", "Calendario general", "Resultados", "Tabla de posiciones"])
        self.report_type_box.grid(row=1, column=0, sticky="w", padx=5)
        self.report_type_box.bind("<<ComboboxSelected>>", lambda _e: self._update_report_controls())
        self.report_round_label = ttk.Label(box, text="Jornada")
        self.report_round_label.grid(row=0, column=1, sticky="w", padx=5, pady=5)
        self.report_round_box = ttk.Combobox(box, textvariable=self.report_round, state="readonly", width=12)
        self.report_round_box.grid(row=1, column=1, sticky="w", padx=5)
        ttk.Label(box, text="Orientación").grid(row=0, column=2, sticky="w", padx=5, pady=5)
        ttk.Combobox(box, textvariable=self.report_orientation, values=["Vertical", "Horizontal"], state="readonly", width=15).grid(row=1, column=2, sticky="w", padx=5)
        self.scope_label = ttk.Label(box, text="Incluir resultados")
        self.scope_label.grid(row=2, column=0, sticky="w", padx=5, pady=(14,5))
        self.scope_box = ttk.Combobox(box, textvariable=self.report_scope, values=["Por jornada", "Todos", "Según estado"], state="readonly", width=18)
        self.scope_box.grid(row=3, column=0, sticky="w", padx=5)
        self.scope_box.bind("<<ComboboxSelected>>", lambda _e: self._update_report_controls())
        self.status_frame = ttk.LabelFrame(box, text="Estados a incluir (puedes elegir varios)", padding=8)
        self.status_frame.grid(row=2, column=1, rowspan=2, columnspan=2, sticky="w", padx=5, pady=(10,0))
        for i, (name, var) in enumerate(self.report_status_vars.items()):
            ttk.Checkbutton(self.status_frame, text=name, variable=var).grid(row=i//3, column=i%3, sticky="w", padx=5, pady=2)
        ttk.Label(box, text="Plantilla de diseño").grid(row=4, column=0, sticky="w", padx=5, pady=(14, 4))
        self.report_design_box = ttk.Combobox(box, textvariable=self.report_design,
            values=["Deportivo moderno", "Liga profesional", "Fútbol clásico", "Impacto deportivo", "Minimalista premium"],
            state="readonly", width=27)
        self.report_design_box.grid(row=5, column=0, sticky="w", padx=5)
        self.report_design_box.bind("<<ComboboxSelected>>", self._save_report_design)
        ttk.Label(box, text="La plantilla elegida se aplicará a los tres tipos de reporte y se recordará para la próxima ocasión.",
                  style="Sub.TLabel", wraplength=620).grid(row=5, column=1, columnspan=2, sticky="w", padx=8)
        ttk.Button(self.reports_tab, text="Generar PDF", style="Accent.TButton", command=self.generate_pdf_report).pack(anchor="w", pady=16)
        ttk.Label(self.reports_tab, text="El Reporte de jornada está diseñado para imprimirse y colocarse en espacios públicos. El Calendario general reúne toda la programación; ninguno muestra estados ni resultados.", style="Sub.TLabel", wraplength=900).pack(anchor="w")
        self._update_report_controls()

    def _build_excel_export(self):
        ttk.Label(self.excel_tab, text="Exportación a Excel", style="Title.TLabel").pack(anchor="w", pady=(0, 14))
        panel = ttk.LabelFrame(self.excel_tab, text="Libro de torneo", padding=18)
        panel.pack(fill="x", anchor="n")
        ttk.Label(panel, text="Genera un archivo .xlsx editable con tres hojas: Equipos, Fixture y Tabla de posiciones.", wraplength=900).pack(anchor="w", pady=(0, 10))
        ttk.Label(panel, text="El archivo incluye los datos actuales del torneo. La exportación no modifica la base de datos.", style="Sub.TLabel", wraplength=900).pack(anchor="w", pady=(0, 14))
        ttk.Button(self.excel_tab, text="Exportar torneo a Excel…", style="Accent.TButton", command=self.export_excel_workbook).pack(anchor="w", pady=4)
        ttk.Label(self.excel_tab, text="Compatible con Microsoft Excel y LibreOffice Calc.", style="Sub.TLabel").pack(anchor="w", pady=(8, 0))

    def export_excel_workbook(self):
        cfg = self.db.get_config()
        if not cfg:
            messagebox.showwarning("Configura el torneo", "Guarda primero el nombre y la temporada del torneo.", parent=self)
            return
        stamp = datetime.now().strftime("%Y%m%d")
        path = filedialog.asksaveasfilename(title="Exportar Liga 82 a Excel", defaultextension=".xlsx",
            initialfile=f"Liga82_{stamp}.xlsx", filetypes=[("Libro de Excel", "*.xlsx")], parent=self)
        if not path:
            return
        try:
            from .excel_export import export_excel
            counts = export_excel(path, cfg, self.db.get_teams(), self.db.get_matches(), self.db.get_standings())
            messagebox.showinfo("Excel generado", "El libro se exportó y verificó correctamente.\n\n"
                f"Equipos: {counts['teams']}\nPartidos: {counts['matches']}\nRegistros de posiciones: {counts['standings']}\n\n{path}", parent=self)
        except ImportError:
            messagebox.showerror("Falta openpyxl", "Instala la dependencia con: python -m pip install openpyxl", parent=self)
        except (ValueError, OSError) as exc:
            messagebox.showerror("No se pudo exportar a Excel", str(exc), parent=self)

    def _save_report_design(self, _event=None):
        self.db.set_setting("report_design", self.report_design.get())

    def _update_report_controls(self):
        kind = self.report_type.get()
        if kind in ("Reporte de jornada", "Calendario por jornada", "Calendario general"):
            if kind == "Calendario general":
                self.report_round_label.grid_remove(); self.report_round_box.grid_remove()
            else:
                self.report_round_label.grid(); self.report_round_box.grid()
            self.scope_label.grid_remove(); self.scope_box.grid_remove(); self.status_frame.grid_remove()
        elif kind == "Resultados":
            self.scope_label.grid(); self.scope_box.grid()
            if self.report_scope.get() == "Por jornada":
                self.report_round_label.grid(); self.report_round_box.grid()
            else:
                self.report_round_label.grid_remove(); self.report_round_box.grid_remove()
            if self.report_scope.get() == "Según estado": self.status_frame.grid()
            else: self.status_frame.grid_remove()
        else:
            self.report_round_label.grid_remove(); self.report_round_box.grid_remove()
            self.scope_label.grid_remove(); self.scope_box.grid_remove(); self.status_frame.grid_remove()

    def _ask_report_observations(self):
        popup = tk.Toplevel(self)
        popup.title("Observaciones de la jornada")
        popup.transient(self); popup.grab_set(); popup.resizable(False, False)
        ttk.Label(popup, text="Observaciones (opcional; aparecerán al pie del reporte):").pack(anchor="w", padx=12, pady=(12, 6))
        box = tk.Text(popup, width=66, height=3, wrap="word")
        box.pack(padx=12, pady=4)
        result = {"value": None}
        buttons = ttk.Frame(popup); buttons.pack(fill="x", padx=12, pady=10)
        def accept():
            result["value"] = box.get("1.0", "end-1c").strip()
            popup.destroy()
        def cancel():
            popup.destroy()
        ttk.Button(buttons, text="Cancelar", command=cancel).pack(side="right", padx=(6, 0))
        ttk.Button(buttons, text="Continuar", style="Accent.TButton", command=accept).pack(side="right")
        popup.wait_window()
        return result["value"]

    def generate_pdf_report(self):
        cfg = self.db.get_config()
        if not cfg:
            messagebox.showwarning("Configura el torneo", "Guarda primero el nombre y la temporada del torneo."); return
        kind = self.report_type.get()
        try:
            round_no = int(self.report_round.get()) if kind in ("Reporte de jornada", "Calendario por jornada") else None
            selected_statuses = None
            if kind == "Resultados":
                scope = self.report_scope.get()
                if scope == "Por jornada":
                    round_no = int(self.report_round.get())
                elif scope == "Según estado":
                    selected_statuses = [name for name, var in self.report_status_vars.items() if var.get()]
                    if not selected_statuses:
                        raise ValueError("Selecciona al menos un estado.")
                else:
                    selected_statuses = None
            path = filedialog.asksaveasfilename(title="Guardar reporte PDF", defaultextension=".pdf", filetypes=[("Documento PDF", "*.pdf")], initialfile=f"Liga82_{kind.replace(' ','_')}.pdf")
            if not path: return
            from .reports import export_report
            observations = self._ask_report_observations() if kind == "Reporte de jornada" else ""
            if observations is None: return
            matches = self.db.get_matches()
            if kind == "Resultados" and self.report_scope.get() == "Por jornada":
                matches = [m for m in matches if m["round_no"] == round_no]
                selected_statuses = None
            count = export_report(path, cfg, matches, self.db.get_teams(), kind, round_no,
                                  ("Vertical" if kind == "Reporte de jornada" else self.report_orientation.get()), selected_statuses, self.db.get_standings(), observations=observations, design=self.report_design.get())
            self._save_report_design()
            messagebox.showinfo("PDF generado", f"Reporte guardado correctamente.\nRegistros incluidos: {count}\n\n{path}")
        except ImportError:
            messagebox.showerror("Falta ReportLab", "Instala la dependencia con: python -m pip install reportlab")
        except (ValueError, OSError) as exc:
            messagebox.showerror("No se pudo generar el PDF", str(exc))

    def add_field(self):
        name = self.field_name.get().strip()
        if not name:
            messagebox.showwarning("Falta el nombre", "Escribe el nombre de la cancha."); return
        try:
            self.db.add_field(name, self.field_address.get().strip())
            self.field_name.set(""); self.field_address.set(""); self.refresh_schedule_admin()
        except sqlite3.IntegrityError:
            messagebox.showerror("Cancha duplicada", "Ya existe una cancha con ese nombre.")

    def delete_field(self):
        sel = self.field_tree.selection()
        if not sel: return
        fid = int(self.field_tree.item(sel[0], "tags")[0])
        if messagebox.askyesno("Eliminar cancha", "Se quitará esta cancha de los partidos asignados. ¿Continuar?"):
            self.db.delete_field(fid); self.refresh_schedule_admin(); self.refresh_fixture()

    def add_referee(self):
        name = self.ref_name.get().strip()
        if not name:
            messagebox.showwarning("Falta el nombre", "Escribe el nombre del árbitro."); return
        try:
            self.db.add_referee(name, self.ref_phone.get().strip())
            self.ref_name.set(""); self.ref_phone.set(""); self.refresh_schedule_admin()
        except sqlite3.IntegrityError:
            messagebox.showerror("Árbitro duplicado", "Ya existe un árbitro con ese nombre.")

    def delete_referee(self):
        sel = self.ref_tree.selection()
        if not sel: return
        rid = int(self.ref_tree.item(sel[0], "tags")[0])
        if messagebox.askyesno("Eliminar árbitro", "Se quitará este árbitro de los partidos asignados. ¿Continuar?"):
            self.db.delete_referee(rid); self.refresh_schedule_admin(); self.refresh_fixture()

    def refresh_schedule_admin(self):
        for tree in (self.field_tree, self.ref_tree):
            for item in tree.get_children(): tree.delete(item)
        for f in self.db.get_fields():
            item = self.field_tree.insert("", "end", values=(f["name"], f["address"]))
            self.field_tree.item(item, tags=(str(f["id"]),))
        for r in self.db.get_referees():
            item = self.ref_tree.insert("", "end", values=(r["name"], r["phone"]))
            self.ref_tree.item(item, tags=(str(r["id"]),))

    def _show_date_picker(self, target, initial_date=None, parent=None):
        try:
            current = datetime.strptime(initial_date, "%Y-%m-%d").date() if initial_date else date.today()
        except ValueError:
            current = date.today()
        popup = tk.Toplevel(parent or self)
        popup.title("Seleccionar fecha")
        popup.resizable(False, False)
        popup.transient(parent or self)
        popup.grab_set()
        year, month = current.year, current.month
        header = ttk.Frame(popup, padding=8); header.pack(fill="x")
        title_var = tk.StringVar()
        ttk.Label(header, textvariable=title_var, font=("Segoe UI", 10, "bold")).pack(side="left", expand=True)
        grid = ttk.Frame(popup, padding=(8,0,8,8)); grid.pack()
        def draw():
            for child in grid.winfo_children(): child.destroy()
            title_var.set(f"{['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'][month-1]} {year}")
            for col, day_name in enumerate(["L","M","M","J","V","S","D"]):
                ttk.Label(grid, text=day_name, width=4, anchor="center").grid(row=0,column=col,padx=1,pady=2)
            import calendar
            for r, week in enumerate(calendar.monthcalendar(year, month), start=1):
                for c, day_num in enumerate(week):
                    if day_num:
                        ttk.Button(grid, text=str(day_num), width=3,
                            command=lambda d=day_num: choose(d)).grid(row=r,column=c,padx=1,pady=1)
        def shift(delta):
            nonlocal year, month
            month += delta
            if month < 1: month=12; year-=1
            if month > 12: month=1; year+=1
            draw()
        def choose(day_num):
            target.set(date(year, month, day_num).isoformat())
            popup.destroy()
        ttk.Button(header, text="‹", width=3, command=lambda: shift(-1)).pack(side="left")
        ttk.Button(header, text="›", width=3, command=lambda: shift(1)).pack(side="right")
        draw()

    def schedule_selected_match(self):
        match_id = self.selected_match_id()
        if match_id is None: return
        match = self.db.get_match(match_id)
        if not match: return
        fields = self.db.get_fields(); refs = self.db.get_referees()
        win = tk.Toplevel(self); win.title("Programar partido"); win.resizable(False, False)
        win.transient(self); win.grab_set()
        body = ttk.Frame(win, padding=18); body.pack(fill="both", expand=True)
        ttk.Label(body, text=f"Jornada {match['round_no']} · {match['home']} vs {match['away']}", style="Title.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        d = tk.StringVar(value=match.get("match_date") or date.today().isoformat())
        tm = tk.StringVar(value=match.get("match_time") or "16:00")
        duration = tk.StringVar(value=str(match.get("duration_min") or 90))
        notes = tk.StringVar(value=match.get("schedule_notes") or "")
        field_options = {"Sin asignar": None}; field_options.update({f["name"]: f["id"] for f in fields})
        ref_options = {"Sin asignar": None}; ref_options.update({r["name"]: r["id"] for r in refs})
        current_field = next((k for k,v in field_options.items() if v == match.get("field_id")), "Sin asignar")
        current_ref = next((k for k,v in ref_options.items() if v == match.get("referee_id")), "Sin asignar")
        fv=tk.StringVar(value=current_field); rv=tk.StringVar(value=current_ref)
        date_controls = ttk.Frame(body)
        ttk.Entry(date_controls, textvariable=d, width=20, state="readonly").pack(side="left")
        ttk.Button(date_controls, text="Calendario…", command=lambda: self._show_date_picker(d, d.get(), win)).pack(side="left", padx=6)
        rows=[("Fecha", date_controls), ("Hora (24 h, HH:MM)",ttk.Entry(body,textvariable=tm,width=28)), ("Duración (minutos)",ttk.Entry(body,textvariable=duration,width=28)), ("Cancha",ttk.Combobox(body,textvariable=fv,values=list(field_options),state="readonly",width=26)), ("Árbitro",ttk.Combobox(body,textvariable=rv,values=list(ref_options),state="readonly",width=26)), ("Observaciones",ttk.Entry(body,textvariable=notes,width=30))]
        for i,(label,widget) in enumerate(rows, start=1):
            ttk.Label(body,text=label).grid(row=i,column=0,sticky="w",pady=5,padx=(0,12)); widget.grid(row=i,column=1,sticky="ew",pady=5)
        def save_schedule():
            try:
                datetime.strptime(d.get().strip(), "%Y-%m-%d")
                datetime.strptime(tm.get().strip(), "%H:%M")
                mins=int(duration.get())
                if mins < 1 or mins > 300: raise ValueError("La duración debe estar entre 1 y 300 minutos.")
                fid=field_options[fv.get()]; rid=ref_options[rv.get()]
                conflicts=self.db.get_schedule_conflicts(match_id,d.get().strip(),tm.get().strip(),mins,fid,rid)
                if conflicts and not messagebox.askyesno("Conflicto de programación", "Se detectaron estos cruces:\n\n"+"\n".join(conflicts)+"\n\n¿Guardar de todos modos?", parent=win): return
                self.db.schedule_match(match_id,d.get().strip(),tm.get().strip(),fid,rid,mins,notes.get().strip())
                win.destroy(); self.refresh_fixture()
            except ValueError as exc:
                messagebox.showerror("Datos no válidos", "Verifica fecha AAAA-MM-DD, hora HH:MM y duración.\n"+str(exc), parent=win)
        buttons=ttk.Frame(body); buttons.grid(row=7,column=0,columnspan=2,sticky="e",pady=(12,0))
        ttk.Button(buttons,text="Cancelar",command=win.destroy).pack(side="right",padx=(8,0))
        ttk.Button(buttons,text="Guardar programación",style="Accent.TButton",command=save_schedule).pack(side="right")

    def _build_table(self):
        ttk.Label(self.table_tab, text="Tabla general de posiciones", style="Title.TLabel").pack(anchor="w", pady=(0, 8))
        ttk.Label(self.table_tab, text="La clasificación se calcula exclusivamente con partidos en estado «Jugado». Desempates: puntos, diferencia de goles y goles a favor.", style="Sub.TLabel").pack(anchor="w", pady=(0, 14))
        cols = ("pos", "team", "pj", "pg", "pe", "pp", "gf", "gc", "dif", "pts")
        self.standings_tree = ttk.Treeview(self.table_tab, columns=cols, show="headings", height=18)
        headings = [
            ("pos", "POS", 55), ("team", "EQUIPO", 260), ("pj", "JJ", 55),
            ("pg", "JG", 55), ("pe", "JE", 55), ("pp", "JP", 55),
            ("gf", "GF", 55), ("gc", "GC", 55), ("dif", "DIF", 65), ("pts", "PTS", 65)
        ]
        for col, title, width in headings:
            self.standings_tree.heading(col, text=title)
            self.standings_tree.column(col, width=width, anchor="center" if col != "team" else "w")
        self.standings_tree.pack(fill="both", expand=True)
        self.table_note = ttk.Label(self.table_tab, text="")
        self.table_note.pack(anchor="w", pady=12)

    def choose_tournament_logo(self):
        path = filedialog.askopenfilename(title="Seleccionar logotipo del torneo", filetypes=[("Imágenes", "*.png *.jpg *.jpeg *.bmp"), ("Todos", "*.*")])
        if path:
            self.t_logo.set(path)

    def save_config(self):
        try:
            vals = [int(self.t_points_win.get()), int(self.t_points_draw.get()), int(self.t_points_loss.get())]
            if not self.t_name.get().strip():
                raise ValueError("Escribe el nombre del torneo.")
            if not self.t_season.get().strip():
                raise ValueError("Escribe la temporada.")
            if min(vals) < 0:
                raise ValueError("Los puntos no pueden ser negativos.")
            logo_path = self.t_logo.get().strip()
            if logo_path and Path(logo_path).is_file():
                logo_dir = Path(__file__).resolve().parent.parent / "logos"
                logo_dir.mkdir(exist_ok=True)
                ext = Path(logo_path).suffix.lower() or ".png"
                destination = logo_dir / f"logo_torneo{ext}"
                if Path(logo_path).resolve() != destination.resolve():
                    shutil.copy2(logo_path, destination)
                logo_path = str(Path("logos") / destination.name)
                self.t_logo.set(logo_path)
            self.db.save_config(self.t_name.get().strip(), self.t_season.get().strip(), self.t_rounds.get(), *vals, logo_path)
            self.config_status.config(text="Configuración guardada correctamente.")
            self.refresh_standings()
        except ValueError as e:
            messagebox.showerror("Datos no válidos", str(e))

    def add_team(self):
        name, city = self.team_name.get().strip(), self.team_city.get().strip()
        if not name:
            messagebox.showwarning("Falta el nombre", "Escribe el nombre del equipo.")
            return
        if len(self.db.get_teams()) >= 20:
            messagebox.showwarning("Límite alcanzado", "La versión 1.1 admite hasta 20 equipos.")
            return
        try:
            self.db.add_team(name, city)
            self.team_name.set("")
            self.team_city.set("")
            self.refresh_all()
        except sqlite3.IntegrityError:
            messagebox.showerror("Equipo duplicado", "Ya existe un equipo con ese nombre.")

    def edit_team_profile(self):
        sel = self.team_tree.selection()
        if not sel:
            messagebox.showinfo("Selecciona un equipo", "Selecciona un equipo y pulsa Editar ficha.")
            return
        team_id = int(self.team_tree.item(sel[0], "values")[0])
        team = next((t for t in self.db.get_teams() if t["id"] == team_id), None)
        if not team:
            return
        win = tk.Toplevel(self)
        win.title(f"Ficha de {team['name']}")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()
        body = ttk.Frame(win, padding=18)
        body.pack(fill="both", expand=True)
        manager = tk.StringVar(value=team.get("manager", ""))
        home_field = tk.StringVar(value=team.get("home_field", ""))
        logo = tk.StringVar(value=team.get("logo_path", ""))
        notes = tk.StringVar(value=team.get("notes", ""))
        ttk.Label(body, text=f"Equipo: {team['name']}", style="Title.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        ttk.Label(body, text="Nombre del encargado").grid(row=1, column=0, sticky="w", pady=5)
        ttk.Entry(body, textvariable=manager, width=42).grid(row=1, column=1, sticky="ew", pady=5)
        ttk.Label(body, text="Campo predeterminado (opcional)").grid(row=2, column=0, sticky="w", pady=5)
        ttk.Entry(body, textvariable=home_field, width=42).grid(row=2, column=1, sticky="ew", pady=5)
        ttk.Label(body, text="Logo / escudo").grid(row=3, column=0, sticky="w", pady=5)
        logo_row = ttk.Frame(body)
        logo_row.grid(row=3, column=1, sticky="ew", pady=5)
        ttk.Entry(logo_row, textvariable=logo, width=30, state="readonly").pack(side="left", fill="x", expand=True)
        def choose_logo():
            selected = filedialog.askopenfilename(parent=win, title="Seleccionar escudo", filetypes=[("Imágenes", "*.png *.jpg *.jpeg *.gif *.bmp"), ("Todos los archivos", "*.*")])
            if selected:
                logo.set(selected)
        ttk.Button(logo_row, text="Examinar…", command=choose_logo).pack(side="left", padx=(6, 0))
        ttk.Label(body, text="Observaciones (opcional)").grid(row=4, column=0, sticky="nw", pady=5)
        notes_entry = tk.Text(body, width=42, height=4, wrap="word")
        notes_entry.grid(row=4, column=1, sticky="ew", pady=5)
        notes_entry.insert("1.0", notes.get())
        def save_profile():
            logo_path = logo.get().strip()
            if logo_path and Path(logo_path).is_file():
                logo_dir = Path(__file__).resolve().parent.parent / "logos"
                logo_dir.mkdir(exist_ok=True)
                src = Path(logo_path)
                dest = logo_dir / f"equipo_{team_id}{src.suffix.lower()}"
                try:
                    if src.resolve() != dest.resolve():
                        shutil.copy2(src, dest)
                    logo_path = str(Path("logos") / dest.name)
                except OSError as exc:
                    messagebox.showerror("No se pudo copiar el logo", str(exc), parent=win)
                    return
            elif logo_path and not Path(logo_path).is_file():
                messagebox.showerror("Logo no encontrado", "Selecciona una imagen válida.", parent=win)
                return
            self.db.update_team_profile(team_id, manager.get().strip(), logo_path,
                                        home_field.get().strip(), notes_entry.get("1.0", "end").strip())
            win.destroy()
            self.refresh_all()
        buttons = ttk.Frame(body)
        buttons.grid(row=5, column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(buttons, text="Cancelar", command=win.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(buttons, text="Guardar ficha", style="Accent.TButton", command=save_profile).pack(side="right")

    def clear_fixture_filters(self):
        self.filter_round.set("Todas")
        self.filter_team.set("Todos")
        self.filter_status.set("Todos")
        self.refresh_fixture()

    def delete_team(self):
        sel = self.team_tree.selection()
        if not sel:
            return
        team_id = int(self.team_tree.item(sel[0], "values")[0])
        if messagebox.askyesno("Confirmar", "¿Eliminar el equipo seleccionado? También se eliminará el fixture para evitar partidos inválidos."):
            self.db.delete_team(team_id)
            self.refresh_all()

    def generate_fixture(self):
        teams = self.db.get_teams()
        if len(teams) < 2:
            messagebox.showwarning("Faltan equipos", "Registra al menos 2 equipos.")
            return
        cfg = self.db.get_config()
        legs = 2 if cfg and cfg["rounds"] == "Dos vueltas" else 1
        pairings = round_robin([t["name"] for t in teams], legs)
        if messagebox.askyesno("Generar fixture", "Se reemplazarán todos los partidos y resultados actuales. ¿Deseas continuar?"):
            self.db.replace_matches(pairings)
            self.refresh_all()
            self.fixture_status.config(text=f"Fixture generado: {len(pairings)} partidos.")

    def selected_match_id(self):
        sel = self.match_tree.selection()
        if not sel:
            messagebox.showinfo("Selecciona un partido", "Primero selecciona un partido de la lista.")
            return None
        return int(self.match_tree.item(sel[0], "tags")[0])

    def edit_result(self):
        match_id = self.selected_match_id()
        if match_id is None:
            return
        match = self.db.get_match(match_id)
        if not match:
            return
        win = tk.Toplevel(self)
        win.title("Capturar / editar resultado")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()
        body = ttk.Frame(win, padding=20)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=f"Jornada {match['round_no']}", style="Sub.TLabel").grid(row=0, column=0, columnspan=3, pady=(0, 12))
        ttk.Label(body, text=match["home"], font=("Segoe UI", 12, "bold")).grid(row=1, column=0, padx=8)
        ttk.Label(body, text="VS", font=("Segoe UI", 10, "bold")).grid(row=1, column=1, padx=8)
        ttk.Label(body, text=match["away"], font=("Segoe UI", 12, "bold")).grid(row=1, column=2, padx=8)
        hg = tk.StringVar(value="" if match["home_goals"] is None else str(match["home_goals"]))
        ag = tk.StringVar(value="" if match["away_goals"] is None else str(match["away_goals"]))
        initial_status = match["status"] if match["status"] in ("Pendiente", "Suspendido", "Reprogramado") else "Automático"
        status = tk.StringVar(value=initial_status)
        ttk.Entry(body, textvariable=hg, width=6, justify="center", font=("Segoe UI", 16)).grid(row=2, column=0, pady=12)
        ttk.Label(body, text="–", font=("Segoe UI", 18, "bold")).grid(row=2, column=1)
        ttk.Entry(body, textvariable=ag, width=6, justify="center", font=("Segoe UI", 16)).grid(row=2, column=2, pady=12)
        ttk.Label(body, text="Estado del partido").grid(row=3, column=0, columnspan=3, sticky="w")
        ttk.Combobox(body, textvariable=status, values=["Automático", "Pendiente", "Suspendido", "Reprogramado"], state="readonly", width=22).grid(row=4, column=0, columnspan=3, sticky="w", pady=(4, 12))
        ttk.Label(body, text="Automático: con marcador completo será Jugado; sin marcador será Programado si tiene fecha y hora, o Pendiente si aún no está programado.", style="Sub.TLabel", wraplength=430).grid(row=5, column=0, columnspan=3, sticky="w")

        def save():
            try:
                if status.get() == "Jugado":
                    if not hg.get().strip() or not ag.get().strip():
                        raise ValueError("Captura los goles de ambos equipos.")
                    home_goals, away_goals = int(hg.get()), int(ag.get())
                    if home_goals < 0 or away_goals < 0:
                        raise ValueError("Los goles no pueden ser negativos.")
                else:
                    if (hg.get().strip() == "") != (ag.get().strip() == ""):
                        raise ValueError("Captura ambos marcadores o deja ambos vacíos.")
                    if hg.get().strip():
                        home_goals, away_goals = int(hg.get()), int(ag.get())
                        if min(home_goals, away_goals) < 0:
                            raise ValueError("Los goles no pueden ser negativos.")
                    else:
                        home_goals = away_goals = None
                if home_goals is not None and away_goals is not None:
                    final_status = "Jugado"
                elif status.get() == "Automático":
                    final_status = "Programado" if match.get("match_date") and match.get("match_time") else "Pendiente"
                else:
                    final_status = status.get()
                self.db.update_match_result(match_id, home_goals, away_goals, final_status)
                win.destroy()
                self.refresh_all()
            except ValueError as e:
                messagebox.showerror("Resultado no válido", str(e), parent=win)
        buttons = ttk.Frame(body)
        buttons.grid(row=6, column=0, columnspan=3, sticky="e", pady=(12, 0))
        ttk.Button(buttons, text="Cancelar", command=win.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(buttons, text="Guardar", style="Accent.TButton", command=save).pack(side="right")

    def clear_result(self):
        match_id = self.selected_match_id()
        if match_id is None:
            return
        match = self.db.get_match(match_id)
        reset_status = "Programado" if match and match.get("match_date") and match.get("match_time") else "Pendiente"
        if messagebox.askyesno("Limpiar resultado", f"¿Borrar el marcador y regresar el partido a {reset_status}?"):
            self.db.update_match_result(match_id, None, None, reset_status)
            self.refresh_all()

    def refresh_fixture(self):
        for item in self.match_tree.get_children():
            self.match_tree.delete(item)
        matches = self.db.get_matches()
        rounds = sorted({m["round_no"] for m in matches})
        self.round_filter_box["values"] = ["Todas"] + [str(r) for r in rounds]
        teams = [t["name"] for t in self.db.get_teams()]
        self.team_filter_box["values"] = ["Todos"] + teams
        if self.filter_round.get() not in self.round_filter_box["values"]:
            self.filter_round.set("Todas")
        if self.filter_team.get() not in self.team_filter_box["values"]:
            self.filter_team.set("Todos")
        visible = []
        for m in matches:
            if self.filter_round.get() != "Todas" and m["round_no"] != int(self.filter_round.get()):
                continue
            if self.filter_team.get() != "Todos" and self.filter_team.get() not in (m["home"], m["away"]):
                continue
            if self.filter_status.get() != "Todos" and m["status"] != self.filter_status.get():
                continue
            visible.append(m)
        for m in visible:
            score = f"{m['home_goals']} – {m['away_goals']}" if m["home_goals"] is not None else "—"
            item = self.match_tree.insert("", "end", values=(m["round_no"], m.get("match_date") or "—", m.get("match_time") or "—", m["home"], score, m["away"], m.get("field_name") or "—", m.get("referee_name") or "—", m["status"]))
            self.match_tree.item(item, tags=(str(m["id"]),))
        self.fixture_status.config(text=f"Mostrando {len(visible)} de {len(matches)} partidos")

    def refresh_standings(self):
        for item in self.standings_tree.get_children():
            self.standings_tree.delete(item)
        rows = self.db.get_standings()
        for pos, row in enumerate(rows, start=1):
            self.standings_tree.insert("", "end", values=(
                pos, row["team"], row["pj"], row["pg"], row["pe"], row["pp"],
                row["gf"], row["gc"], row["dif"], row["pts"]
            ))
        played = sum(r["pj"] for r in rows) // 2
        self.table_note.config(text=f"Partidos jugados contabilizados: {played}. Los partidos no jugados no suman puntos ni estadísticas.")

    def refresh_all(self):
        cfg = self.db.get_config()
        if cfg:
            self.t_name.set(cfg["name"])
            self.t_season.set(cfg["season"])
            self.t_rounds.set(cfg["rounds"])
            self.t_points_win.set(str(cfg["points_win"]))
            self.t_points_draw.set(str(cfg["points_draw"]))
            self.t_points_loss.set(str(cfg["points_loss"]))
            self.t_logo.set(cfg.get("logo_path") or "")
        for item in self.team_tree.get_children():
            self.team_tree.delete(item)
        teams = self.db.get_teams()
        for t in teams:
            self.team_tree.insert("", "end", values=(t["id"], t["name"], t["city"]))
        self.team_count.config(text=f"{len(teams)} / 20 equipos")
        self.refresh_fixture()
        self.refresh_standings()
        self.refresh_schedule_admin()
        self._refresh_poster_rounds()
        rounds = sorted({m["round_no"] for m in self.db.get_matches()})
        self.report_round_box["values"] = [str(x) for x in rounds] or ["1"]
        if self.report_round.get() not in self.report_round_box["values"]: self.report_round.set((rounds or [1])[0] and str((rounds or [1])[0]))

    def on_close(self):
        if getattr(self, "auto_backup_var", None) is not None and self.auto_backup_var.get():
            try:
                backup_path = create_backup(self.db.conn, default_backup_dir())
            except Exception as exc:
                if not messagebox.askyesno("No se pudo crear el respaldo", f"Ocurrió un error al crear el respaldo automático:\n{exc}\n\n¿Deseas cerrar Liga 82 de todos modos?", icon="warning", parent=self):
                    return
        self.db.close()
        self.destroy()

if __name__ == "__main__":
    import sqlite3
    app = Liga82App()
    app.mainloop()
