"""Generador independiente de carteles para redes sociales de Liga 82."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageFilter

W, H = 1080, 1350
GREEN = (35, 210, 112)
WHITE = (255, 255, 255)


def _font(size, bold=False):
    candidates = [
        Path('C:/Windows/Fonts/seguisb.ttf' if bold else 'C:/Windows/Fonts/segoeui.ttf'),
        Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),
    ]
    for p in candidates:
        if p.exists():
            return ImageFont.truetype(str(p), size)
    return ImageFont.load_default()


def _cover(path):
    try:
        im = Image.open(path).convert('RGB')
        return ImageOps.fit(im, (W, H), method=Image.Resampling.LANCZOS)
    except Exception:
        return None


def _fallback_background():
    im = Image.new('RGB', (W, H), (5, 17, 24))
    px = im.load()
    for y in range(H):
        t = y / H
        c = (int(5+2*t), int(23-13*t), int(31-16*t))
        for x in range(W): px[x, y] = c
    glow = Image.new('RGBA', (W, H), (0,0,0,0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((-180, 100, 380, 720), fill=(40, 255, 150, 65))
    gd.ellipse((700, 40, 1260, 700), fill=(70, 190, 255, 55))
    glow = glow.filter(ImageFilter.GaussianBlur(95))
    im = Image.alpha_composite(im.convert('RGBA'), glow)
    d = ImageDraw.Draw(im)
    d.polygon([(0,900),(W,900),(W,H),(0,H)], fill=(4,35,27,220))
    for y in range(930, H, 70): d.line((0,y,W,y-70), fill=(30,100,65,75), width=2)
    return im.convert('RGB')


def _fit_text(draw, text, max_width, size, bold=True, min_size=18):
    f = _font(size, bold)
    while size > min_size and draw.textbbox((0,0), text, font=f)[2] > max_width:
        size -= 2; f = _font(size, bold)
    return f


def _paste_logo(canvas, path, box, initials='?'):
    x0,y0,x1,y1 = box
    if path and Path(path).is_file():
        try:
            logo = Image.open(path).convert('RGBA')
            logo.thumbnail((x1-x0, y1-y0), Image.Resampling.LANCZOS)
            canvas.alpha_composite(logo, (x0+(x1-x0-logo.width)//2, y0+(y1-y0-logo.height)//2))
            return
        except Exception: pass
    d = ImageDraw.Draw(canvas)
    d.ellipse(box, fill=(235,245,240,245), outline=GREEN, width=4)
    f = _font(42, True); bb=d.textbbox((0,0), initials[:3].upper(), font=f)
    d.text(((x0+x1-(bb[2]-bb[0]))/2,(y0+y1-(bb[3]-bb[1]))/2-5), initials[:3].upper(), font=f, fill=(13,60,40))


def render_poster(config, round_no, matches, teams, sponsors=None, background_path=None, output_path=None):
    """Renderiza cartel 4:5. matches deben ser de una sola jornada."""
    bg = _cover(background_path) if background_path else None
    if bg is None: bg = _fallback_background()
    canvas = bg.convert('RGBA')
    overlay = Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(overlay)
    d.rectangle((0,0,W,260), fill=(0,0,0,145))
    d.rectangle((0,260,W,1230), fill=(0,0,0,95))
    d.rectangle((0,1230,W,H), fill=(0,0,0,185))
    d.rectangle((0,0,W,13), fill=GREEN)
    canvas=Image.alpha_composite(canvas,overlay); d=ImageDraw.Draw(canvas)

    logo_path=config.get('logo_path') or ''
    if logo_path and Path(logo_path).is_file():
        _paste_logo(canvas,logo_path,(38,35,170,167))
    tournament=(config.get('name') or 'TORNEO').upper()
    d.text((190,52),tournament,font=_fit_text(d,tournament,830,43,True,25),fill=WHITE,stroke_width=1,stroke_fill=(0,0,0,120))
    season=str(config.get('season') or '')
    d.text((194,111),f'TEMPORADA {season}'.strip(),font=_font(22),fill=(210,235,220))
    title=f'JORNADA {int(round_no):02d}'
    f=_font(68,True); bb=d.textbbox((0,0),title,font=f)
    d.text(((W-(bb[2]-bb[0]))/2,174),title,font=f,fill=GREEN,stroke_width=2,stroke_fill=(0,0,0,180))

    matches=sorted(matches,key=lambda m:(m.get('match_time') or '99:99',m.get('id',0)))
    n=len(matches)
    if n>10: raise ValueError('Una jornada no puede mostrar más de 10 partidos en un solo cartel.')
    if not n:
        d.text((W//2,650),'SIN PARTIDOS PROGRAMADOS',font=_font(32,True),fill=WHITE,anchor='mm')
    else:
        rows=(n+1)//2
        top=290; bottom=1200
        gap=16
        available_h=bottom-top
        # Las jornadas pequeñas usan tarjetas más amplias y se centran
        # verticalmente; las jornadas numerosas reducen su altura de forma
        # proporcional para conservar todos los encuentros dentro del cartel.
        row_h=min(250,(available_h-gap*(rows-1))//rows)
        block_h=rows*row_h+gap*(rows-1)
        vertical_offset=(available_h-block_h)//2
        teammap={t['name'].casefold():t for t in teams}
        for i,m in enumerate(matches):
            col=i%2; row=i//2
            # En cantidad impar, el último enfrentamiento se centra a todo lo ancho.
            if n%2 and i==n-1:
                x0=75; x1=W-75
            else:
                x0=38+col*522; x1=x0+500
            y0=top+vertical_offset+row*(row_h+gap); y1=y0+row_h
            d.rounded_rectangle((x0,y0,x1,y1),radius=22,fill=(5,20,22,220),outline=(75,205,130,220),width=3)
            mid=(x0+x1)//2
            home=str(m.get('home') or 'Local'); away=str(m.get('away') or 'Visitante')
            home_team=teammap.get(home.casefold(),{}); away_team=teammap.get(away.casefold(),{})
            logo_y=y0+10; logo_size=min(68,row_h//2)
            _paste_logo(canvas,home_team.get('logo_path'),(x0+35,logo_y,x0+35+logo_size,logo_y+logo_size),home[:2])
            _paste_logo(canvas,away_team.get('logo_path'),(x1-35-logo_size,logo_y,x1-35,logo_y+logo_size),away[:2])
            d=ImageDraw.Draw(canvas)
            d.text((mid,y0+logo_size//2+16),'VS',font=_font(31,True),fill=GREEN,anchor='mm')
            name_y=y0+logo_size+36
            label_width=220 if x1-x0<600 else 330
            home_c=x0+(x1-x0)*0.27
            away_c=x0+(x1-x0)*0.73
            hf=_fit_text(d,home,label_width,20,True,13)
            af=_fit_text(d,away,label_width,20,True,13)
            d.text((home_c,name_y),home,font=hf,fill=WHITE,anchor='mm')
            d.text((away_c,name_y),away,font=af,fill=WHITE,anchor='mm')
            date=m.get('match_date') or ''
            if date:
                try:
                    from datetime import datetime
                    date=datetime.strptime(date,'%Y-%m-%d').strftime('%d/%m/%Y')
                except ValueError: pass
            else: date='Fecha por confirmar'
            tm=m.get('match_time') or 'Hora por confirmar'
            field=m.get('field_name') or 'Cancha por confirmar'
            meta=f'{date}   •   {tm}   •   {field}'
            mf=_fit_text(d,meta,x1-x0-34,17,False,12)
            d.text((mid,y1-22),meta,font=mf,fill=(220,235,225),anchor='ms')

    active=[s for s in (sponsors or []) if s.get('active',True) and s.get('path') and Path(s['path']).is_file()]
    if active:
        d=ImageDraw.Draw(canvas); d.text((W//2,1250),'PATROCINAN',font=_font(16,True),fill=(205,225,215),anchor='mm')
        maxw=min(170,(W-80)//len(active)); y0=1270
        for idx,s in enumerate(active):
            try:
                im=Image.open(s['path']).convert('RGBA'); im.thumbnail((maxw,65),Image.Resampling.LANCZOS)
                x=40+idx*(maxw+((W-80-len(active)*maxw)//max(1,len(active)-1)))
                canvas.alpha_composite(im,(x,y0+(65-im.height)//2))
            except Exception: pass
    result=canvas.convert('RGB')
    if output_path:
        ext=Path(output_path).suffix.lower()
        if ext in ('.jpg','.jpeg'): result.save(output_path,'JPEG',quality=94,optimize=True)
        else: result.save(output_path,'PNG',optimize=True)
    return result
