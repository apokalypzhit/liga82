from pathlib import Path
from datetime import datetime
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape, portrait
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                Image, KeepTogether, HRFlowable)
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader

GREEN = colors.HexColor("#174d32")
DARK = colors.HexColor("#123b29")
LIGHT = colors.HexColor("#edf4ef")
MUTED = colors.HexColor("#587064")

DESIGNS = {
    "Deportivo moderno": ("#1769E0", "#101827", "#EAF1FC", "#52647A"),
    "Liga profesional": ("#142B4A", "#B89445", "#F5F1E7", "#667085"),
    "Fútbol clásico": ("#17613B", "#103D29", "#EAF3EC", "#587064"),
    "Impacto deportivo": ("#D62828", "#171717", "#F3EEEE", "#555555"),
    "Minimalista premium": ("#17324D", "#087E8B", "#EDF3F5", "#64748B"),
}



def _safe_logo(path, max_w=22*mm, max_h=22*mm):
    if not path:
        return None
    p = Path(path)
    if not p.is_absolute():
        p = Path(__file__).resolve().parent.parent / p
    if not p.is_file():
        return None
    try:
        im = Image(str(p))
        scale = min(max_w / im.imageWidth, max_h / im.imageHeight)
        im.drawWidth = im.imageWidth * scale
        im.drawHeight = im.imageHeight * scale
        return im
    except Exception:
        return None


def _date(value):
    if not value:
        return "Fecha por definir"
    try:
        return datetime.strptime(value, "%Y-%m-%d").strftime("%d/%m/%Y")
    except (TypeError, ValueError):
        return str(value)


def _team_logo(team_name, team_map, max_w=10*mm, max_h=10*mm):
    team = team_map.get(str(team_name or '').casefold(), {})
    return _safe_logo(team.get('logo_path'), max_w, max_h)


def _team_cell(team_name, team_map, style, max_w=8*mm, max_h=8*mm, logo_first=True):
    """Celda compacta con escudo real; permite orientar el escudo hacia el rival."""
    label = Paragraph(escape(str(team_name or '')), style)
    logo = _team_logo(team_name, team_map, max_w, max_h)
    if logo:
        contents = [logo, label] if logo_first else [label, logo]
        cell = Table([contents], colWidths=[max_w + 2*mm, None] if logo_first else [None, max_w + 2*mm])
        cell.setStyle(TableStyle([
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'), ('ALIGN',(0,0),(0,0),'CENTER'),
            ('LEFTPADDING',(0,0),(-1,-1),1), ('RIGHTPADDING',(0,0),(-1,-1),1),
            ('TOPPADDING',(0,0),(-1,-1),1), ('BOTTOMPADDING',(0,0),(-1,-1),1),
        ]))
        return cell
    return label


def _poster_report(story, doc, config, matches, round_no, observations, palette, team_map):
    primary, accent, light, muted = [colors.HexColor(v) for v in palette]
    styles = getSampleStyleSheet()
    title = ParagraphStyle("PosterTitle", parent=styles["Title"], fontName="Helvetica-Bold",
                           fontSize=20, leading=23, textColor=primary, alignment=TA_CENTER, spaceAfter=3)
    subtitle = ParagraphStyle("PosterSubtitle", parent=styles["Normal"], fontSize=10, leading=13,
                              textColor=muted, alignment=TA_CENTER)
    round_style = ParagraphStyle("Round", parent=styles["Heading2"], fontName="Helvetica-Bold",
                                 fontSize=16, leading=19, textColor=colors.white, alignment=TA_CENTER)
    date_style = ParagraphStyle("Date", parent=styles["Normal"], fontName="Helvetica-Bold",
                                fontSize=9, leading=11, textColor=accent, alignment=TA_CENTER)
    team_style = ParagraphStyle("Team", parent=styles["Normal"], fontName="Helvetica-Bold",
                                fontSize=12, leading=15, textColor=DARK, alignment=TA_CENTER)
    meta_style = ParagraphStyle("Meta", parent=styles["Normal"], fontSize=8.5, leading=11,
                                textColor=muted, alignment=TA_CENTER)
    obs_style = ParagraphStyle("Obs", parent=styles["Normal"], fontSize=9, leading=12, textColor=accent)

    logo = _safe_logo(config.get("logo_path"), 25*mm, 25*mm)
    name = Paragraph(escape(config.get("name") or "LIGA 82"), title)
    season = Paragraph(f"TEMPORADA {escape(str(config.get('season') or ''))}", subtitle)
    if logo:
        header = Table([[logo, [name, season]]], colWidths=[30*mm, doc.width-30*mm])
        header.setStyle(TableStyle([("VALIGN", (0,0),(-1,-1),"MIDDLE"),
                                    ("ALIGN",(1,0),(1,0),"CENTER"),
                                    ("LEFTPADDING",(0,0),(-1,-1),2),
                                    ("RIGHTPADDING",(0,0),(-1,-1),2),
                                    ("BOTTOMPADDING",(0,0),(-1,-1),5)]))
        story.append(header)
    else:
        story.extend([name, season])
    story.append(Spacer(1, 5*mm))
    band = Table([[Paragraph(f"PROGRAMACIÓN · JORNADA {round_no:02d}", round_style)]], colWidths=[doc.width])
    band.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),primary), ("TOPPADDING",(0,0),(-1,-1),8),
                              ("BOTTOMPADDING",(0,0),(-1,-1),8)]))
    story.append(band)
    story.append(Spacer(1, 3*mm))

    matches = sorted(matches, key=lambda m: (m.get("match_date") or "9999", m.get("match_time") or "99:99", m.get("id",0)))
    if not matches:
        story.append(Paragraph("No hay partidos registrados para esta jornada.", styles["Normal"]))
        return 0

    for index, m in enumerate(matches, 1):
        when = f"{_date(m.get('match_date'))}  ·  {m.get('match_time') or 'Hora por definir'}"
        teams = Table([[_team_cell(m.get("home"), team_map, team_style, 9*mm, 9*mm, logo_first=False),
                        Paragraph("VS", ParagraphStyle("VS", parent=team_style, fontSize=9, textColor=muted)),
                        _team_cell(m.get("away"), team_map, team_style, 9*mm, 9*mm, logo_first=True)]],
                      colWidths=[doc.width*.44, doc.width*.12, doc.width*.44])
        teams.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"MIDDLE"),
                                   ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),
                                   ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),4)]))
        details = Paragraph(
            f"<b>CANCHA:</b> {escape(m.get('field_name') or 'Por asignar')}"
            f"  &nbsp;&nbsp; <b>ÁRBITRO:</b> {escape(m.get('referee_name') or 'Por asignar')}", meta_style)
        card = Table([[Paragraph(when, date_style)], [teams], [details]], colWidths=[doc.width])
        card.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),light),
                                  ("BOX",(0,0),(-1,-1),.7,muted),
                                  ("LINEBELOW",(0,0),(-1,0),.4,muted),
                                  ("TOPPADDING",(0,0),(-1,-1),4),
                                  ("BOTTOMPADDING",(0,0),(-1,-1),5),
                                  ("LEFTPADDING",(0,0),(-1,-1),7),
                                  ("RIGHTPADDING",(0,0),(-1,-1),7)]))
        story.append(KeepTogether([card, Spacer(1, 3*mm)]))

    story.append(Spacer(1, 2*mm))
    story.append(Paragraph("OBSERVACIONES", ParagraphStyle("ObsHead", parent=styles["Heading3"],
                      fontName="Helvetica-Bold", fontSize=9, textColor=primary, spaceAfter=3)))
    obs_text = escape(observations or "").replace("\n", "<br/>")
    lines = obs_text if obs_text else "________________________________________________________________________________<br/><br/>________________________________________________________________________________<br/><br/>________________________________________________________________________________"
    obs = Table([[Paragraph(lines, obs_style)]], colWidths=[doc.width], rowHeights=[27*mm if not obs_text else None])
    obs.setStyle(TableStyle([("BOX",(0,0),(-1,-1),.6,muted),
                             ("LEFTPADDING",(0,0),(-1,-1),7),("RIGHTPADDING",(0,0),(-1,-1),7),
                             ("TOPPADDING",(0,0),(-1,-1),6),("BOTTOMPADDING",(0,0),(-1,-1),6),
                             ("VALIGN",(0,0),(-1,-1),"TOP")]))
    story.append(obs)
    story.append(Spacer(1, 4*mm))
    story.append(Paragraph(f"Liga 82 · Documento generado el {datetime.now().strftime('%d/%m/%Y')}", subtitle))
    return len(matches)


def _page_background(canvas, doc, design):
    """Fondo deportivo sutil, generado localmente y sin afectar la legibilidad."""
    from pathlib import Path
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import mm
    asset = Path(__file__).resolve().parent / "report_assets" / (design.replace(" ", "_") + ".jpg")
    if asset.is_file():
        w, h = doc.pagesize
        canvas.saveState()
        canvas.drawImage(str(asset), 0, 0, width=w, height=h, preserveAspectRatio=False, mask='auto')
        # Panel translúcido: deja visible la identidad deportiva sin sacrificar lectura.
        canvas.setFillColor(colors.Color(1, 1, 1, alpha=0.70))
        canvas.rect(7*mm, 7*mm, w-14*mm, h-14*mm, fill=1, stroke=0)
        # Marco y acento superior coordinados con cada plantilla.
        palette = DESIGNS.get(design, DESIGNS["Fútbol clásico"])
        canvas.setStrokeColor(colors.HexColor(palette[0]))
        canvas.setLineWidth(1.8)
        canvas.roundRect(7*mm, 7*mm, w-14*mm, h-14*mm, 3*mm, fill=0, stroke=1)
        canvas.setFillColor(colors.HexColor(palette[0]))
        canvas.roundRect(7*mm, h-10*mm, w-14*mm, 3*mm, 1.5*mm, fill=1, stroke=0)
        canvas.restoreState()


def export_report(path, config, matches, teams, report_type="Calendario por jornada", round_no=None,
                  orientation="Vertical", selected_statuses=None, standings=None, observations="", design="Fútbol clásico"):
    # El Calendario General es un documento interno de consulta: se mantiene sobrio,
    # sin fondos decorativos ni tratamientos gráficos de las cinco plantillas.
    plain_calendar = report_type == "Calendario general"
    palette = ("#555555", "#777777", "#FFFFFF", "#555555") if plain_calendar else DESIGNS.get(design, DESIGNS["Fútbol clásico"])
    primary, accent, light, muted = [colors.HexColor(v) for v in palette]
    poster = report_type == "Reporte de jornada"
    pagesize = portrait(letter) if poster else (landscape(letter) if orientation == "Horizontal" else portrait(letter))
    doc = SimpleDocTemplate(str(path), pagesize=pagesize, rightMargin=12*mm, leftMargin=12*mm,
                            topMargin=10*mm if poster else 12*mm, bottomMargin=12*mm,
                            title=f"{config.get('name','Liga 82')} - {report_type}")
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("L82Title", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=16,
                                 leading=19, textColor=primary, alignment=TA_CENTER, spaceAfter=3)
    sub_style = ParagraphStyle("L82Sub", parent=styles["Normal"], fontSize=9, leading=12,
                               textColor=muted, alignment=TA_CENTER)
    cell = ParagraphStyle("L82Cell", parent=styles["Normal"], fontSize=7.2, leading=8.5)
    story = []
    team_map = {str(t.get("name", "")).casefold(): t for t in (teams or [])}

    if poster:
        filtered = [m for m in matches if m["round_no"] == round_no]
        count = _poster_report(story, doc, config, filtered, round_no or 1, observations, palette, team_map)
    elif report_type == "Tabla de posiciones":
        logo = _safe_logo(config.get("logo_path"), 27*mm, 27*mm)
        title = Paragraph(escape(config.get("name") or "Liga 82"), title_style)
        season = Paragraph(f"Temporada {escape(str(config.get('season','')))} · Tabla de posiciones", sub_style)
        if logo:
            masthead = Table([[logo, [title, season]]], colWidths=[27*mm, doc.width-27*mm])
            masthead.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('ALIGN',(1,0),(1,0),'CENTER'),
                                         ('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2)]))
            story.append(masthead)
        else:
            story.extend([title, season])
        story.append(Spacer(1, 6*mm))
        data = [["Pos.","Equipo","JJ","JG","JE","JP","GF","GC","DIF","PTS"]]
        for i, r in enumerate(standings or [], 1):
            data.append([i,_team_cell(r['team'], team_map, cell, 9.5*mm, 9.5*mm),r['pj'],r['pg'],r['pe'],r['pp'],r['gf'],r['gc'],r['dif'],r['pts']])
        widths = [11*mm, None, 12*mm,12*mm,12*mm,12*mm,12*mm,12*mm,12*mm,14*mm]
        widths[1] = doc.width - sum(x for x in widths if x is not None)
        tbl = Table(data, colWidths=widths, repeatRows=1); count = len(standings or [])
        standings_cmds = [("BACKGROUND",(0,0),(-1,0),primary),
                          ("TEXTCOLOR",(0,0),(-1,0),colors.white),
                          ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
                          ("FONTSIZE",(0,0),(-1,-1),8),
                          ("GRID",(0,0),(-1,-1),.4,muted),
                          ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
                          ("ALIGN",(0,0),(-1,-1),"CENTER"),
                          ("LEFTPADDING",(0,0),(-1,-1),4),
                          ("RIGHTPADDING",(0,0),(-1,-1),4),
                          ("TOPPADDING",(0,0),(-1,-1),6),
                          ("BOTTOMPADDING",(0,0),(-1,-1),6)]
        for row in range(1, len(data)):
            if row % 2 == 0:
                standings_cmds.append(("BACKGROUND",(0,row),(-1,row),light))
        # Destacar visualmente la columna de puntos y al líder de la clasificación.
        standings_cmds.extend([
            ("BACKGROUND",(9,1),(9,-1),colors.Color(accent.red, accent.green, accent.blue, alpha=0.13)),
            ("FONTNAME",(9,0),(9,-1),"Helvetica-Bold"),
            ("TEXTCOLOR",(9,1),(9,-1),primary),
        ])
        # Resaltar en negritas las primeras ocho posiciones, sin podio ni
        # cambios de color que alteren la jerarquía visual de la clasificación.
        for row in range(1, min(9, len(data))):
            standings_cmds.append(("FONTNAME", (0,row), (-1,row), "Helvetica-Bold"))
        tbl.setStyle(TableStyle(standings_cmds))
        story.append(tbl)
    else:
        filtered = list(matches)
        if report_type == "Calendario por jornada":
            filtered = [m for m in filtered if m['round_no'] == round_no]
        elif report_type == "Resultados" and selected_statuses:
            filtered = [m for m in filtered if m.get('status') in selected_statuses]
        filtered.sort(key=lambda m: (m.get('match_date') or '9999', m.get('match_time') or '99:99', m['round_no'], m['id']))
        count = len(filtered)
        title_text = "Calendario general" if report_type == "Calendario general" else report_type
        story.extend([Paragraph(escape(config.get("name") or "Liga 82"), title_style),
                      Paragraph(f"Temporada {escape(str(config.get('season','')))} · {escape(title_text)}", sub_style),
                      Spacer(1, 6*mm)])
        if not filtered:
            story.append(Paragraph("No hay partidos que coincidan con los criterios seleccionados.", styles["Normal"]))
        else:
            if report_type in ("Calendario general", "Calendario por jornada"):
                headers = ["Jor.","Fecha","Hora","Local","Visitante","Cancha","Árbitro"]
                data = [headers]
                for m in filtered:
                    data.append([str(m['round_no']),_date(m.get('match_date')),m.get('match_time') or "—",
                                 _team_cell(m['home'],team_map,cell,9*mm,9*mm,logo_first=False),_team_cell(m['away'],team_map,cell,9*mm,9*mm,logo_first=True),
                                 Paragraph(escape(m.get('field_name') or "—"),cell),Paragraph(escape(m.get('referee_name') or "—"),cell)])
                widths = [10*mm,22*mm,15*mm,None,None,None,None]
                fixed=sum(x for x in widths if x is not None); rem=doc.width-fixed
                widths[3],widths[4],widths[5],widths[6]=rem*.27,rem*.27,rem*.23,rem*.23
            else:
                headers = ["Jor.","Fecha","Hora","Local","Marcador","Visitante","Cancha","Árbitro","Estado"]
                data = [headers]
                for m in filtered:
                    score = f"{m['home_goals']} - {m['away_goals']}" if m.get('home_goals') is not None and m.get('away_goals') is not None else "—"
                    data.append([str(m['round_no']),_date(m.get('match_date')),m.get('match_time') or "—",
                                 _team_cell(m['home'],team_map,cell,logo_first=False),score,_team_cell(m['away'],team_map,cell,logo_first=True),
                                 Paragraph(escape(m.get('field_name') or "—"),cell),Paragraph(escape(m.get('referee_name') or "—"),cell),m.get('status') or "Pendiente"])
                widths=[9*mm,19*mm,13*mm,None,17*mm,None,None,None,20*mm]
                fixed=sum(x for x in widths if x is not None); rem=doc.width-fixed
                widths[3],widths[5],widths[6],widths[7]=rem*.24,rem*.24,rem*.18,rem*.20
            tbl=Table(data,colWidths=widths,repeatRows=1)
            header_bg = colors.HexColor("#E5E7EB") if plain_calendar else primary
            header_fg = colors.HexColor("#222222") if plain_calendar else colors.white
            cmds=[("BACKGROUND",(0,0),(-1,0),header_bg),("TEXTCOLOR",(0,0),(-1,0),header_fg),
                  ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),7),
                  ("GRID",(0,0),(-1,-1),.35,muted),("VALIGN",(0,0),(-1,-1),"MIDDLE"),
                  ("ALIGN",(0,0),(-1,-1),"CENTER"),("LEFTPADDING",(0,0),(-1,-1),3),
                  ("RIGHTPADDING",(0,0),(-1,-1),3),("TOPPADDING",(0,0),(-1,-1),4),
                  ("BOTTOMPADDING",(0,0),(-1,-1),4)]
            if not plain_calendar:
                for row in range(1,len(data)):
                    if row%2==0: cmds.append(("BACKGROUND",(0,row),(-1,row),light))
            tbl.setStyle(TableStyle(cmds)); story.append(tbl)
        story.append(Spacer(1,5*mm))
        story.append(Paragraph(f"Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')} · Liga 82",sub_style))
    if plain_calendar:
        doc.build(story)
    else:
        doc.build(story, onFirstPage=lambda c, d: _page_background(c, d, design),
                  onLaterPages=lambda c, d: _page_background(c, d, design))
    return count
