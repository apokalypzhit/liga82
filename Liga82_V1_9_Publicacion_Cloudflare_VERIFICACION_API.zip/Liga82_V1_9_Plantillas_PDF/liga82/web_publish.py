"""Generación de una página web estática e independiente para la tabla general."""
from datetime import datetime
from pathlib import Path
from html import escape
import shutil


def generate_standings_site(config, standings, output_dir):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    tournament = (config or {}).get("name") or "Torneo de fútbol"
    season = (config or {}).get("season") or ""
    logo_path = (config or {}).get("logo_path") or ""
    logo_html = ""
    if logo_path:
        source = Path(logo_path)
        if source.is_file():
            ext = source.suffix.lower() or ".png"
            target = output / f"logo_torneo{ext}"
            if source.resolve() != target.resolve():
                shutil.copy2(source, target)
            logo_html = f'<img class="tournament-logo" src="{escape(target.name)}" alt="Logotipo del torneo">'

    rows = []
    crest_dir = output / "escudos_equipos"
    crest_dir.mkdir(exist_ok=True)
    for pos, item in enumerate(standings, start=1):
        position_class = "top-eight" if pos <= 8 else ""
        if pos <= 3:
            position_class += " top-three"
        team_name = str(item.get("team", ""))
        team = escape(team_name)
        crest_html = ""
        crest_path = str(item.get("logo_path") or "").strip()
        if crest_path:
            source_crest = Path(crest_path)
            if source_crest.is_file():
                ext = source_crest.suffix.lower() or ".png"
                safe_stem = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in team_name).strip("_") or f"equipo_{pos}"
                crest_name = f"{pos:02d}_{safe_stem}{ext}"
                target_crest = crest_dir / crest_name
                if source_crest.resolve() != target_crest.resolve():
                    shutil.copy2(source_crest, target_crest)
                crest_html = f'<img class="team-crest" src="{escape((Path("escudos_equipos") / crest_name).as_posix())}" alt="Escudo de {team}" loading="lazy">'
        if not crest_html:
            initials = "".join(part[0] for part in team_name.split()[:2] if part)[:2].upper() or "⚽"
            crest_html = f'<span class="team-crest crest-placeholder" aria-label="Sin escudo">{escape(initials)}</span>'
        rows.append(
            f'<tr class="{position_class}">'
            f'<td class="position">{pos}</td><th scope="row" class="team"><span class="team-cell">{crest_html}<span>{team}</span></span></th>'
            f'<td>{item.get("pj", 0)}</td><td>{item.get("pg", 0)}</td>'
            f'<td>{item.get("pe", 0)}</td><td>{item.get("pp", 0)}</td>'
            f'<td>{item.get("gf", 0)}</td><td>{item.get("gc", 0)}</td>'
            f'<td>{item.get("dif", 0):+d}</td><td class="points">{item.get("pts", 0)}</td>'
            '</tr>'
        )
    if not rows:
        rows.append('<tr><td colspan="10" class="empty">Todavía no hay equipos registrados.</td></tr>')

    generated = datetime.now().strftime("%d/%m/%Y %H:%M")
    title = escape(tournament)
    season_html = f'<span class="season">{escape(str(season))}</span>' if season else ''
    html = f'''<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#075b3b">
<meta name="description" content="Tabla general de posiciones de {title}">
<title>Tabla general | {title}</title>
<style>
:root{{--green:#075b3b;--green2:#0b8152;--lime:#b8e34b;--ink:#17352a;--muted:#6b7c73;--paper:#fff;--line:#e2ebe5}}
*{{box-sizing:border-box}}body{{margin:0;background:linear-gradient(145deg,#eaf4ed,#f8fbf8 55%,#e2eee6);color:var(--ink);font-family:Arial,Helvetica,sans-serif;min-height:100vh}}
.hero{{background:linear-gradient(115deg,#06452f,#08764c 70%,#0d8b58);color:white;padding:30px 18px 42px;position:relative;overflow:hidden}}
.hero:after{{content:"";position:absolute;width:360px;height:360px;border:1px solid #ffffff22;border-radius:50%;right:-100px;top:-210px;box-shadow:0 0 0 35px #ffffff0c,0 0 0 70px #ffffff09}}
.brand{{max-width:1100px;margin:auto;display:flex;align-items:center;gap:18px;position:relative;z-index:1}}
.tournament-logo{{width:76px;height:76px;object-fit:contain;background:#ffffff;border-radius:16px;padding:6px}}
h1{{font-size:clamp(25px,4vw,38px);margin:0 0 6px;font-weight:800;letter-spacing:.2px}}.season{{display:inline-block;color:#e3f5b4;font-weight:700;letter-spacing:1px}}
main{{max-width:1100px;margin:-22px auto 40px;padding:0 16px;position:relative;z-index:2}}.panel{{background:var(--paper);border-radius:18px;box-shadow:0 12px 35px #123b2615;overflow:hidden}}
.panel-head{{padding:20px 22px 14px;display:flex;justify-content:space-between;align-items:end;gap:12px}}h2{{margin:0;font-size:21px;color:var(--green)}}.updated{{font-size:12px;color:var(--muted)}}
.table-wrap{{overflow-x:auto;padding:0 14px 16px}}table{{width:100%;border-collapse:separate;border-spacing:0;min-width:720px;font-size:14px}}thead th{{background:#edf5ef;color:#456456;text-align:center;font-size:11px;letter-spacing:.5px;padding:13px 9px;white-space:nowrap}}thead th:first-child{{border-radius:9px 0 0 9px}}thead th:last-child{{border-radius:0 9px 9px 0}}
tbody td,tbody th{{padding:13px 9px;border-bottom:1px solid var(--line);text-align:center;font-weight:500}}tbody tr:last-child td,tbody tr:last-child th{{border-bottom:0}}tbody .team{{text-align:left;font-weight:700;min-width:210px}}.team-cell{{display:flex;align-items:center;gap:10px}}.team-crest{{width:34px;height:34px;object-fit:contain;flex:0 0 34px;border-radius:50%;background:#f3f7f4;padding:3px}}.crest-placeholder{{display:inline-flex;align-items:center;justify-content:center;background:#e5f1e8;color:var(--green);font-size:11px;font-weight:800}}.position{{font-weight:800;color:var(--muted);width:42px}}.top-three .position{{color:var(--green2)}}.top-three:first-child .position{{background:#f1f8d9;border-radius:9px}}.top-eight td,.top-eight th{{background:#eff5ff}}.top-eight .position{{color:#285d9b;font-weight:900}}.top-eight .points{{background:#e4efff;color:#174f8d}}.points{{font-weight:900;color:var(--green);font-size:16px;background:#f1f8f3}}.empty{{padding:28px;color:var(--muted)}}
.legend{{display:flex;flex-wrap:wrap;gap:14px;padding:0 22px 18px;color:var(--muted);font-size:12px}}.legend b{{color:var(--green)}}footer{{text-align:center;color:#72847a;font-size:12px;padding:0 16px 28px}}
@media(max-width:600px){{.hero{{padding:22px 16px 38px}}.brand{{gap:12px}}.tournament-logo{{width:58px;height:58px}}.panel-head{{padding:17px 16px 12px;display:block}}.updated{{display:block;margin-top:6px}}.table-wrap{{padding:0 9px 12px}}}}
@media print{{body{{background:white}}.hero{{print-color-adjust:exact;-webkit-print-color-adjust:exact}}main{{margin:16px auto}}.panel{{box-shadow:none}}}}
</style>
</head>
<body>
<header class="hero"><div class="brand">{logo_html}<div><h1>{title}</h1>{season_html}</div></div></header>
<main><section class="panel"><div class="panel-head"><h2>Tabla general</h2><span class="updated">Actualizada: {generated}</span></div>
<div class="table-wrap"><table><thead><tr><th>POS</th><th style="text-align:left">EQUIPO</th><th>JJ</th><th>JG</th><th>JE</th><th>JP</th><th>GF</th><th>GC</th><th>DIF</th><th>PTS</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div>
<div class="legend"><span style="background:#eff5ff;border:1px solid #d8e6fb;border-radius:5px;padding:4px 7px;color:#285d9b;font-weight:700">8 primeros lugares</span><span><b>JJ</b> Jugados</span><span><b>JG</b> Ganados</span><span><b>JE</b> Empatados</span><span><b>JP</b> Perdidos</span><span><b>GF</b> Goles a favor</span><span><b>GC</b> Goles en contra</span><span><b>DIF</b> Diferencia</span><span><b>PTS</b> Puntos</span></div>
</section></main><footer>Generado con Liga 82 · Administración de torneo</footer>
</body></html>'''
    page = output / "index.html"
    page.write_text(html, encoding="utf-8")
    instructions = output / "LEEME.txt"
    instructions.write_text(
        "PÁGINA WEB - TABLA GENERAL LIGA 82\n\n"
        "Abre index.html con cualquier navegador para consultar la tabla.\n"
        "La página funciona sin instalar programas y puede copiarse completa a un\n"
        "servicio de alojamiento web cuando se decida dónde publicarla.\n\n"
        "Para actualizarla, vuelve a generar la página desde Liga 82 y reemplaza\n"
        "los archivos anteriores por los nuevos. Conserva juntos index.html y el\n"
        "archivo del logotipo si se generó uno, así como la carpeta escudos_equipos.\n",
        encoding="utf-8"
    )
    return page
