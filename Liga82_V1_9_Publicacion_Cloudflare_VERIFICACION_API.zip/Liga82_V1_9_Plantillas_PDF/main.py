from liga82.main import Liga82App

if __name__ == "__main__":
    app = Liga82App()
    app.mainloop()
